<?php
session_start();
require 'firebase_config.php'; // Ensure Firebase is configured

// Check if the user is logged in, otherwise redirect
if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_name'])) {
    header("Location: index.html");
    exit();
}

$adminName = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Management</title>
    <link rel="stylesheet" href="admin_styles.css">

    <!-- Firebase SDK -->
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-firestore.js"></script>

    <script>
        // Firebase Configuration
        const firebaseConfig = {
            apiKey: "AIzaSyC1Y7dJKv5dOBKGkMf_KYS8FNMLxWjJyE",
            authDomain: "compmed-ar.firebaseapp.com",
            projectId: "compmed-ar",
            storageBucket: "compmed-ar.appspot.com",
            messagingSenderId: "523184550566",
            appId: "1:523184550566:android:a540c878273f0f1b067a67",
            measurementId: "G-E6GVGHKWDP"
        };

        // Initialize Firebase
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        } else {
            firebase.app();
        }

        const db = firebase.firestore();

        // Fetch Admins
        async function fetchAdmins() {
            const adminTable = document.getElementById("adminTable").getElementsByTagName("tbody")[0];
            adminTable.innerHTML = ''; // Clear existing table

            const querySnapshot = await db.collection("allowedAdmins").get();
            querySnapshot.forEach(doc => {
                const adminData = doc.data();
                const row = adminTable.insertRow();
                row.insertCell(0).textContent = doc.id; // Email as document name
                row.insertCell(1).textContent = adminData.name;

                // Action Buttons
                const actionCell = row.insertCell(2);
                actionCell.innerHTML = `
                    <button onclick="editAdmin('${doc.id}', '${adminData.name}')">Edit</button>
                    <button onclick="deleteAdmin('${doc.id}')">Delete</button>
                `;
            });
        }

        // Fetch admins on page load
        window.onload = fetchAdmins;

        // Open Add Admin Modal
        function openAddAdminModal() {
            document.getElementById("addAdminModal").style.display = "flex";
        }

        // Close Add Admin Modal
        function closeAddAdminModal() {
            document.getElementById("addAdminModal").style.display = "none";
        }

        // Add Admin
        async function addAdmin() {
            const email = document.getElementById("adminEmail").value.trim();
            const name = document.getElementById("adminName").value.trim();

            if (email === "" || name === "") {
                alert("Please enter both email and name.");
                return;
            }

            try {
                await db.collection("allowedAdmins").doc(email).set({ name });
                alert("Admin added successfully!");
                closeAddAdminModal();
                fetchAdmins();
            } catch (error) {
                console.error("Error adding admin:", error);
                alert("Failed to add admin.");
            }
        }

        // Open Edit Admin Modal
        function editAdmin(email, name) {
            document.getElementById("editAdminEmail").value = email;
            document.getElementById("editAdminName").value = name;
            document.getElementById("editAdminModal").style.display = "flex";
        }

        // Close Edit Admin Modal
        function closeEditAdminModal() {
            document.getElementById("editAdminModal").style.display = "none";
        }

        // Save Edited Admin
        async function saveAdminChanges() {
            const email = document.getElementById("editAdminEmail").value;
            const newName = document.getElementById("editAdminName").value.trim();

            if (newName === "") {
                alert("Name cannot be empty.");
                return;
            }

            try {
                await db.collection("allowedAdmins").doc(email).update({ name: newName });
                alert("Admin updated successfully!");
                closeEditAdminModal();
                fetchAdmins();
            } catch (error) {
                console.error("Error updating admin:", error);
                alert("Failed to update admin.");
            }
        }

        // Delete Admin
        async function deleteAdmin(email) {
            if (!confirm("Are you sure you want to delete this admin?")) return;

            try {
                await db.collection("allowedAdmins").doc(email).delete();
                alert("Admin deleted successfully!");
                fetchAdmins();
            } catch (error) {
                console.error("Error deleting admin:", error);
                alert("Failed to delete admin.");
            }
        }
    </script>
</head>
<body>
    <a href="dashboard.php" class="dashboard-btn">← Return to Dashboard</a>
    <h2>Admin Management</h2>

	<div class="add-admin-container">
		<button class="add-admin-btn" onclick="openAddAdminModal()">+ Add Admin</button>
	</div>
    <!-- Admin Table -->
    <table id="adminTable">
        <thead>
            <tr>
                <th>Email</th>
                <th>Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>

    <!-- Add Admin Modal -->
    <div id="addAdminModal" class="modal">
        <div class="modal-content">
            <button class="close-button" onclick="closeAddAdminModal()">❌</button>
            <h3>Add Admin</h3>
            <label>Email:</label>
            <input type="email" id="adminEmail" placeholder="Enter admin email" required>
            <label>Name:</label>
            <input type="text" id="adminName" placeholder="Enter admin name" required>
            <button onclick="addAdmin()">Add Admin</button>
        </div>
    </div>

    <!-- Edit Admin Modal -->
    <div id="editAdminModal" class="modal">
        <div class="modal-content">
            <button class="close-button" onclick="closeEditAdminModal()">❌</button>
            <h3>Edit Admin</h3>
            <label>Email:</label>
            <input type="email" id="editAdminEmail" disabled>
            <label>Name:</label>
            <input type="text" id="editAdminName" required>
			<br><br>
            <button class="button-1" onclick="saveAdminChanges()">Save Changes</button>
        </div>
    </div>

</body>
</html>
