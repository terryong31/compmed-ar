<?php
session_start();

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['message' => 'Method not allowed.']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['email']) || !isset($input['name'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Email and name are required.']);
    exit();
}

$email = $input['email'];
$name = $input['name'];

// Start the session and store admin details
$_SESSION['user_email'] = $email;
$_SESSION['user_name'] = $name;

// Respond with success
http_response_code(200);
echo json_encode(['message' => 'Login successful', 'redirect' => 'dashboard.php']);
?>