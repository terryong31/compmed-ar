<?php
session_start();
require 'firebase_config.php'; // Ensure Firebase is configured

if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_name'])) {
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Subjects</title>

    <!-- ✅ Link to External Stylesheet -->
    <link rel="stylesheet" href="subjectstyles.css">

    <!-- ✅ Firebase Compatibility SDKs -->
    <script src="https://www.gstatic.com/firebasejs/9.6.10/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.6.10/firebase-auth-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.6.10/firebase-firestore-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.6.10/firebase-storage-compat.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

    <script>
    // ✅ Firebase Configuration
    const firebaseConfig = {
        apiKey: "AIzaSyC1Y7dJKv5dOBKGkMf_KYS8FNMLxwFjJyE",
        authDomain: "compmed-ar.firebaseapp.com",
        projectId: "compmed-ar",
        storageBucket: "compmed-ar.appspot.com",
        messagingSenderId: "523184550566",
        appId: "1:523184550566:android:a540c878273f0f1b067a67",
        measurementId: "G-E6GVGHKWDP"
    };

    // ✅ Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    const db = firebase.firestore();
    const storage = firebase.storage();

    // ✅ Function to Load Subjects
// Flag to ensure loadSubjects runs only once
let hasLoadedSubjects = false;

async function loadSubjects() {
    if (hasLoadedSubjects) {
        console.log("Subjects already loaded, skipping...");
        return; // Prevent multiple executions
    }

    try {
        console.log("Starting to load subjects...");

        const subjectSelect = document.getElementById("subjectSelect");
        const subjectList = document.getElementById("subjectList");

        // Clear the dropdown completely
        subjectSelect.innerHTML = "<option value=''>Select Subject</option>";
        subjectList.innerHTML = "";

        const snapshot = await db.collection("subjects").get();
        console.log("Firestore snapshot retrieved, number of documents:", snapshot.docs.length);

        const addedSubjects = new Set(); // Track unique subjects by subjectCode
        let subjectHTML = "";

        for (const doc of snapshot.docs) {
            const subjectCode = doc.id;
            const data = doc.data();
            const subjectName = data.name || subjectCode;
            const previewImage = data.previewImage || "default_preview.png";

            console.log("Processing subject:", subjectCode, subjectName);

            if (!addedSubjects.has(subjectCode)) {
                subjectSelect.innerHTML += `<option value="${subjectCode}">${subjectName}</option>`;
                addedSubjects.add(subjectCode);

                subjectHTML += `
                    <div class="subject-container" id="subject-${subjectCode}">
                        <img src="${previewImage}" class="subject-image">
                        <div class="subject-details">
                            <span class="subject-name">${subjectName} (${subjectCode})</span>
                        </div>
                        <div class="action-buttons">
                            <button class="edit-btn" onclick="editSubject('${subjectCode}')">✏️ Edit</button>
                            <button class="delete-btn" onclick="deleteSubject('${subjectCode}')">🗑 Delete</button>
                        </div>
                    </div>
                `;
            } else {
                console.warn("Duplicate subjectCode found, skipping:", subjectCode);
            }
        }

        subjectList.innerHTML = subjectHTML;
        console.log("Subjects loaded, total unique subjects:", addedSubjects.size);

        hasLoadedSubjects = true; // Mark as loaded
    } catch (error) {
        console.error("Error loading subjects:", error);
    }
}

// Ensure loadSubjects is called only once when the page loads
document.addEventListener("DOMContentLoaded", () => {
    loadSubjects();
    // Ensure modal is hidden when the page loads
    document.getElementById("modal").style.display = "none";
    document.getElementById("modalOverlay").style.display = "none";
});


    // ✅ Function to Delete Subject and its Files from Firebase Storage
	async function deleteSubject(subjectCode) {
		if (confirm(`Are you sure you want to delete "${subjectCode}" and all its data?`)) {
			try {
				// Get subject document data (for preview image & QR code)
				const subjectDoc = await db.collection("subjects").doc(subjectCode).get();
				if (subjectDoc.exists) {
					const subjectData = subjectDoc.data();

					// Delete preview image if exists
					if (subjectData.previewImage) {
						await deleteFileFromStorage(subjectData.previewImage);
					}

					// Delete QR code if exists
					if (subjectData.qrCodeURL) {
						await deleteFileFromStorage(subjectData.qrCodeURL);
					}
				}

				// Step 1: Get all topics under the subject
				const topicsRef = db.collection("subjects").doc(subjectCode).collection("topics");
				const topicsSnapshot = await topicsRef.get();

				// Step 2: Loop through each topic and delete associated files in Firebase Storage
				for (let doc of topicsSnapshot.docs) {
					const topicData = doc.data();

					// Delete video file if exists
					if (topicData.video) await deleteFileFromStorage(topicData.video);

					// Delete document file if exists
					if (topicData.document) await deleteFileFromStorage(topicData.document);

					// Delete images if exist
					if (topicData.images && Array.isArray(topicData.images)) {
						for (let imgUrl of topicData.images) {
							await deleteFileFromStorage(imgUrl);
						}
					}

					// Delete topic description file if exists
					if (topicData.description) await deleteFileFromStorage(topicData.description);

					// Step 3: Delete the topic from Firestore
					await doc.ref.delete();
				}

				// Step 4: Delete the subject document from Firestore
				await db.collection("subjects").doc(subjectCode).delete();

				alert(`✅ Subject "${subjectCode}" and all its files have been deleted!`);
				loadSubjects(); // Refresh the list
			} catch (error) {
				console.error("⚠️ Error deleting subject and files:", error);
			}
		}
	}

	// ✅ Function to Properly Delete a File from Firebase Storage
	async function deleteFileFromStorage(fileURL) {
		if (!fileURL) return;
		try {
			const storageService = firebase.storage();
			const storageRef = storageService.refFromURL(fileURL); // ✅ Properly get reference
			await storageRef.delete();
			console.log(`✅ Deleted: ${fileURL}`);
		} catch (error) {
			console.warn(`⚠️ Failed to delete file: ${fileURL}`, error);
		}
	}

		// ✅ Function to Show Popup Modal
		function showPopup(title, content, onSave) {
			document.getElementById("modalTitle").textContent = title;
			document.getElementById("modalContent").innerHTML = content;
			document.getElementById("modal").style.display = "block";
			document.getElementById("modalOverlay").style.display = "block";
			document.getElementById("modalSave").onclick = onSave;
		}

		// ✅ Function to Close Popup Modal
		function closePopup() {
			document.getElementById("modal").style.display = "none";
			document.getElementById("modalOverlay").style.display = "none";
		}

		// ✅ Function to Generate a Unique Subject Code
		function generateSubjectCode(subjectTitle) {
			const randomNum = Math.floor(1000 + Math.random() * 9000); // Generate a random 4-digit number
			return `${subjectTitle.substring(0, 3).toUpperCase()}-${randomNum}`;
		}

		// ✅ Function to Convert QR Code to Blob (For Uploading)
		function generateQRCodeBlob(subjectCode) {
			return new Promise((resolve, reject) => {
				const qrDiv = document.createElement("div"); // Temporary QR code container
				const qr = new QRCode(qrDiv, {
					text: subjectCode,
					width: 256,
					height: 256
				});

				setTimeout(() => {
					const canvas = qrDiv.querySelector("canvas");
					if (!canvas) {
						reject("QR code generation failed.");
						return;
					}

					canvas.toBlob(blob => resolve(blob), "image/png");
				}, 500); // Small delay to ensure QR code is rendered
			});
		}

		// ✅ Function to Add Subject with QR Code
		async function addSubject() {
			const subjectTitle = document.getElementById("subjectTitle").value.trim();
			const previewImageFile = document.getElementById("subjectPreviewImageFile").files[0]; // ✅ New Preview Image Input

			if (!subjectTitle) {
				alert("Subject title is required.");
				return;
			}

			const subjectCode = generateSubjectCode(subjectTitle); // Generate subject code

			try {
				let previewImageURL = "";
				if (previewImageFile) {
					previewImageURL = await uploadFile(previewImageFile, `subjects/${subjectCode}/preview.jpg`);
				}

				const qrBlob = await generateQRCodeBlob(subjectCode);
				const qrStoragePath = `subjects/${subjectCode}/qr_code.png`;

				// ✅ Upload QR Code to Firebase Storage
				const qrStorageRef = storage.ref(qrStoragePath);
				await qrStorageRef.put(qrBlob);
				const qrCodeURL = await qrStorageRef.getDownloadURL();

				// ✅ Save Subject Info to Firestore (Document ID is subjectCode)
				await db.collection("subjects").doc(subjectCode).set({
					name: subjectTitle,
					subjectCode: subjectCode,
					qrCodeURL: qrCodeURL,
					previewImage: previewImageURL  // ✅ Store the preview image in Firestore
				});

				alert("Subject added successfully with QR Code and Preview Image!");
				loadSubjects();
			} catch (error) {
				console.error("Error adding subject:", error);
			}
		}

		async function addTopic() {
			const subjectTitle = document.getElementById("subjectSelect").value;
			let topicNumber = document.getElementById("topicNumber").value.trim();
			const videoFile = document.getElementById("videoFile").files[0];
			const documentFile = document.getElementById("documentFile").files[0];
			const imageFiles = document.getElementById("imageFiles").files;
			const topicDescription = document.getElementById("topicDescription").value.trim();

			if (!subjectTitle || !topicNumber) {
				alert("Select a subject and enter a valid topic number.");
				return;
			}

			const topicName = `Topic ${topicNumber}`;

			try {
				let videoURL = videoFile ? await uploadFile(videoFile, `subjects/${subjectTitle}/topics/${topicName}/video.mp4`) : "";
				let documentURL = documentFile ? await uploadFile(documentFile, `subjects/${subjectTitle}/topics/${topicName}/document.pdf`) : "";

				let imageURLs = [];
				for (let i = 0; i < imageFiles.length; i++) {
					let imageURL = await uploadFile(imageFiles[i], `subjects/${subjectTitle}/topics/${topicName}/image_${i + 1}.jpg`);
					imageURLs.push(imageURL);
				}

				let descriptionURL = await uploadTextFile(topicDescription, `subjects/${subjectTitle}/topics/${topicName}/description.txt`);

				// ✅ Save to Firestore
				await db.collection("subjects").doc(subjectTitle).collection("topics").doc(topicName).set({
					name: topicName,
					video: videoURL,
					document: documentURL,
					images: imageURLs,
					description: descriptionURL
				});

				alert(`"${topicName}" added successfully!`);
				loadSubjects();
			} catch (error) {
				console.error("Error adding topic:", error);
			}
		}

		async function uploadFile(file, path) {
			return new Promise((resolve, reject) => {
				const storageRef = storage.ref(path);
				const uploadTask = storageRef.put(file);

				const progressBar = document.getElementById("uploadProgressBar");
				const progressContainer = document.querySelector(".progress-bar-container");

				progressContainer.style.display = "block"; // ✅ Show the progress bar
				progressBar.style.width = "0%"; // ✅ Reset progress

				uploadTask.on(
					"state_changed",
					(snapshot) => {
						const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
						progressBar.style.width = `${progress}%`;
					},
					(error) => reject(error),
					async () => {
						progressBar.style.width = "100%"; // ✅ Ensure full width on completion
						setTimeout(() => {
							progressContainer.style.display = "none"; // ✅ Hide after a short delay
							progressBar.style.width = "0%"; // ✅ Reset for next upload
						}, 500);
						
						const downloadURL = await uploadTask.snapshot.ref.getDownloadURL();
						resolve(downloadURL);
					}
				);
			});
		}

        async function uploadTextFile(text, path) {
            return new Promise((resolve, reject) => {
                const textBlob = new Blob([text], { type: "text/plain" });
                const storageRef = storage.ref(path);
                const uploadTask = storageRef.put(textBlob);

                uploadTask.on(
                    "state_changed",
                    null, 
                    error => reject(error),
                    () => {
                        uploadTask.snapshot.ref.getDownloadURL().then(resolve).catch(reject);
                    }
                );
            });
        }

		async function editSubject(subjectCode) {
			try {
				const subjectDoc = await db.collection("subjects").doc(subjectCode).get();
				if (!subjectDoc.exists) {
					alert("Subject not found.");
					return;
				}

				const data = subjectDoc.data();
				const subjectName = data.name || subjectCode;
				const qrCodeURL = data.qrCodeURL || "default_qr.png";
				const previewImageURL = data.previewImage || "default_preview.png";

				// Show Popup with Editable Fields, ensuring #editTopics is initially empty
				showPopup("Edit Subject", `
					<label>New Subject Name:</label>
					<input type="text" id="editSubjectName" value="${subjectName}"><br>

					<label>QR Code:</label>
					<img src="${qrCodeURL}" id="qrCodeImg" onclick="enlargeQR('${qrCodeURL}')" 
						style="width: 100px; cursor: pointer;"><br>

					<label>Preview Image:</label>
					<img src="${previewImageURL}" id="previewImg" 
						style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px;"><br>
					<label>Edit Preview Image:</label>
					<input type="file" id="editPreviewImageFile"><br>

					<div id="editTopics"></div>
					<div id="loadingSpinner" class="loading-spinner" style="display: none;"></div>
				`, async () => {
					document.getElementById("loadingSpinner").style.display = "block";

					const newSubjectName = document.getElementById("editSubjectName").value.trim();
					const newPreviewImageFile = document.getElementById("editPreviewImageFile").files[0];

					if (!newSubjectName) {
						alert("Subject name cannot be empty.");
						document.getElementById("loadingSpinner").style.display = "none";
						return;
					}

					let newPreviewImageURL = previewImageURL;
					if (newPreviewImageFile) {
						await deleteFileFromStorage(previewImageURL);
						newPreviewImageURL = await uploadFile(newPreviewImageFile, `subjects/${subjectCode}/preview.jpg`);
					}

					await db.collection("subjects").doc(subjectCode).update({
						name: newSubjectName,
						previewImage: newPreviewImageURL
					});

					alert("Subject updated successfully!");
					document.getElementById("loadingSpinner").style.display = "none";
					closePopup();
					loadSubjects(); // Refresh the subject list
				});

				// Load topics after the modal is shown, ensuring no duplicates
				loadTopicsForEdit(subjectCode);
			} catch (error) {
				console.error("Error editing subject:", error);
			}
		}

		async function uploadFileWithProgress(file, path, progressBarId) {
			return new Promise((resolve, reject) => {
				const storageRef = storage.ref(path);
				const uploadTask = storageRef.put(file);
				const progressBar = document.getElementById(progressBarId);

				uploadTask.on(
					"state_changed",
					(snapshot) => {
						const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
						progressBar.style.width = `${progress}%`;
					},
					(error) => reject(error),
					async () => {
						progressBar.style.width = "100%"; // ✅ Full progress when completed
						setTimeout(() => {
							progressBar.style.width = "0%"; // ✅ Reset
						}, 500);
						const downloadURL = await uploadTask.snapshot.ref.getDownloadURL();
						resolve(downloadURL);
					}
				);
			});
		}

		function enlargeQR(qrURL) {
			document.getElementById("qrModal").style.display = "flex";
			document.getElementById("qrImage").src = qrURL;
		}

		function closeQRModal() {
			document.getElementById("qrModal").style.display = "none";
		}

		async function loadTopics(subject) {
			try {
				const topicContainer = document.getElementById(`topics-${subject}`);
				if (!topicContainer) return;

				topicContainer.innerHTML = "";

				const snapshot = await db.collection("subjects").doc(subject).collection("topics").get();
				let topicHTML = "";

				for (const doc of snapshot.docs) {
					const topic = doc.id;
					const data = doc.data();

					topicHTML += `
						<p>
							<b>${topic}</b><br>
							<img src="${data.previewImage ? data.previewImage : "default_qr.png"}" 
								 alt="Preview Image" style="width: 100px; height: 100px; object-fit: cover;"><br>
							Video: ${data.video ? `<a href="${data.video}" target="_blank">View</a>` : "No Video"}<br>
							Document: ${data.document ? `<a href="${data.document}" target="_blank">View</a>` : "No Document"}<br>
							Images: ${data.images ? data.images.map(img => `<a href="${img}" target="_blank">Image</a>`).join(", ") : "No Images"}
							<button onclick="editTopic('${subject}', '${topic}')">✏️ Edit</button>
							<button onclick="deleteTopic('${subject}', '${topic}')">🗑 Delete</button>
						</p>
					`;
				}

				topicContainer.innerHTML = topicHTML;
			} catch (error) {
				console.error(`Error loading topics for subject ${subject}:`, error);
			}
		}

		async function loadTopicsForEdit(subjectCode) {
			const editTopicsDiv = document.getElementById("editTopics");

			if (!editTopicsDiv) {
				console.error(`Element with ID "editTopics" not found.`);
				return;
			}

			// Clear the editTopics div to prevent duplicates
			editTopicsDiv.innerHTML = "";
			console.log(`Cleared topics for subject ${subjectCode}`);

			try {
				const snapshot = await db.collection("subjects").doc(subjectCode).collection("topics").get();
				console.log(`Firestore snapshot for topics under ${subjectCode}, number of documents:`, snapshot.docs.length);

				const addedTopics = new Set(); // Track unique topics by topicID

				snapshot.forEach(doc => {
					const topicID = doc.id;
					const topicName = doc.data().name || topicID;

					// Log each topic being processed
					console.log(`Processing topic: ${topicID}, Name: ${topicName}`);

					// Only add if the topicID hasn't been added yet
					if (!addedTopics.has(topicID)) {
						editTopicsDiv.innerHTML += `
							<p>
								${topicName} 
								<button id="editbutton1" onclick="editTopic('${subjectCode}', '${topicID}')">✏️ Edit</button>
								<button id="deletebutton1" onclick="deleteTopic('${subjectCode}', '${topicID}')">🗑 Delete</button>
							</p>
						`;
						addedTopics.add(topicID);
					} else {
						console.warn(`Duplicate topicID found, skipping: ${topicID}`);
					}
				});

				console.log(`Topics loaded for subject ${subjectCode}, total unique topics:`, addedTopics.size);
			} catch (error) {
				console.error(`Error loading topics for subject ${subjectCode}:`, error);
			}
		}

		// ✅ Function to Delete Topic from Firestore and Storage
		async function deleteTopic(subjectCode, topicID) {
			if (!confirm(`Are you sure you want to delete "${topicID}"?`)) return;

			try {
				const topicDoc = await db.collection("subjects").doc(subjectCode).collection("topics").doc(topicID).get();
				if (!topicDoc.exists) {
					alert("Topic not found.");
					return;
				}

				const topicData = topicDoc.data();

				// ✅ Delete associated files (video, document, images, description)
				if (topicData.video) await deleteFileFromStorage(topicData.video);
				if (topicData.document) await deleteFileFromStorage(topicData.document);
				if (topicData.images && Array.isArray(topicData.images)) {
					for (let imgUrl of topicData.images) {
						await deleteFileFromStorage(imgUrl);
					}
				}
				if (topicData.description) await deleteFileFromStorage(topicData.description);

				// ✅ Delete topic document from Firestore
				await db.collection("subjects").doc(subjectCode).collection("topics").doc(topicID).delete();

				alert(`Topic "${topicID}" deleted successfully!`);
				loadTopicsForEdit(subjectCode); // Refresh the topic list
			} catch (error) {
				console.error("Error deleting topic:", error);
				alert("Failed to delete topic.");
			}
		}

		// ✅ Function to Edit a Topic (Retrieve & Modify .txt Description)
		async function editTopic(subjectCode, topicID) {
			try {
				const topicDoc = await db.collection("subjects").doc(subjectCode).collection("topics").doc(topicID).get();
				if (!topicDoc.exists) {
					alert("Topic not found.");
					return;
				}

				const topicData = topicDoc.data();
				let descriptionText = "";

				// ✅ Retrieve Description Text from Firebase Storage
				if (topicData.description) {
					try {
						const response = await fetch(topicData.description);
						descriptionText = await response.text();
					} catch (error) {
						console.warn("Failed to load description file:", error);
						descriptionText = "";
					}
				}

				// ✅ Show the Popup with Editable Fields
				showPopup(`Edit ${topicData.name}`, `
					<label>Update Video:</label>
					<input type="file" accept=".mp4" id="editVideoFile"><br>
					
					<label>Update Document:</label>
					<input type="file" accept=".docx,.pdf" id="editDocumentFile"><br>
					
					<label>Update Images (Multiple Allowed):</label>
					<input type="file" accept=".png,.jpg" id="editImageFiles" multiple><br>
					
					<label>Update Description:</label>
					<textarea id="editTopicDescription">${descriptionText}</textarea><br>

					<!-- ✅ Loading Spinner (Initially Hidden) -->
					<div id="loadingSpinner" class="loading-spinner" style="display: none;"></div>
				`, async () => {
					const saveButton = document.getElementById("modalSave");
					const loadingSpinner = document.getElementById("loadingSpinner");

					// ✅ Show Loading Spinner and Disable Save Button
					saveButton.disabled = true;
					loadingSpinner.style.display = "block";

					const newVideoFile = document.getElementById("editVideoFile").files[0];
					const newDocumentFile = document.getElementById("editDocumentFile").files[0];
					const newImageFiles = document.getElementById("editImageFiles").files;
					const newTopicDescription = document.getElementById("editTopicDescription").value.trim();

					let videoURL = topicData.video || "";
					let documentURL = topicData.document || "";
					let imageURLs = topicData.images || [];
					let descriptionURL = topicData.description || "";
					let previewImageURL = topicData.previewImage || "";

					try {
						// ✅ Upload new video if selected
						if (newVideoFile) {
							await deleteFileFromStorage(videoURL);
							videoURL = await uploadFile(newVideoFile, `subjects/${subjectCode}/topics/${topicID}/video.mp4`);
						}

						// ✅ Upload new document if selected
						if (newDocumentFile) {
							await deleteFileFromStorage(documentURL);
							documentURL = await uploadFile(newDocumentFile, `subjects/${subjectCode}/topics/${topicID}/document.pdf`);
						}

						// ✅ Upload new images if selected
						if (newImageFiles.length > 0) {
							for (let imgUrl of imageURLs) {
								await deleteFileFromStorage(imgUrl);
							}
							imageURLs = [];
							for (let i = 0; i < newImageFiles.length; i++) {
								let imageURL = await uploadFile(newImageFiles[i], `subjects/${subjectCode}/topics/${topicID}/image_${i + 1}.jpg`);
								imageURLs.push(imageURL);
							}
						}

						// ✅ Upload Updated Description to Firebase Storage
						if (newTopicDescription !== descriptionText) {
							if (descriptionURL) await deleteFileFromStorage(descriptionURL);
							descriptionURL = await uploadTextFile(newTopicDescription, `subjects/${subjectCode}/topics/${topicID}/description.txt`);
						}

						// ✅ Prepare update object, ensuring no undefined values
						let updateData = {
							video: videoURL,
							document: documentURL,
							images: imageURLs,
							description: descriptionURL
						};

						// ✅ Only include `previewImage` if it's not undefined
						if (previewImageURL) {
							updateData.previewImage = previewImageURL;
						}

						// ✅ Update Firestore document with only valid fields
						await db.collection("subjects").doc(subjectCode).collection("topics").doc(topicID).update(updateData);

						alert(`"${topicData.name}" updated successfully!`);
						closePopup();
						loadTopicsForEdit(subjectCode); // ✅ Return to Topic Selection Instead of Subject Selection
					} catch (error) {
						console.error("Error updating topic:", error);
					} finally {
						// ✅ Hide Loading Spinner and Enable Save Button
						loadingSpinner.style.display = "none";
						saveButton.disabled = false;
					}
				});
			} catch (error) {
				console.error("Error editing topic:", error);
			}
		}

    </script>
</head>
<body>
	<div class="header">
		<button class="back-btn" onclick="window.location.href='dashboard.php'">← Back</button>
		<span>Manage Subjects</span>
	</div>
	<div class="container">
    <h2>Create a Subject</h2>
    <input type="text" placeholder="Enter Subject Name" id="subjectTitle">
	<label>Preview Image:</label>
	<input type="file" accept=".png,.jpg" id="subjectPreviewImageFile"><br> <!-- ✅ Added for Preview Image Upload -->
    <button onclick="addSubject()">Add Subject</button>

	<br><br>
    <h2>Add Topic to Subject</h2>
    <label>Select Subject:</label>
    <select id="subjectSelect"></select>
    <br>
    <label>Topic Number:</label>
    <input type="number" id="topicNumber"><br>
    <label>Topic Description:</label>
    <textarea placeholder="Enter Description Here" id="topicDescription"></textarea><br>
    <label>Upload Video:</label>
    <input type="file" accept=".mp4" id="videoFile"><br>
    <label>Upload Document:</label>
    <input type="file" accept=".docx,.pdf" id="documentFile"><br>
    <label>Upload Images for Topic (Multiple Allowed)	:</label>
    <input type="file" accept=".jpg,.png" id="imageFiles" multiple><br>
    <button onclick="addTopic()">Add Topic</button>
	<!-- ✅ Progress Bar for Upload -->
	<div class="progress-bar-container">
		<div id="uploadProgressBar" class="progress-bar"></div>
	</div>

	
	<br><br>
    <h2>Manage Subjects & Topics</h2>
    <div id="subjectList"></div>

    <div id="modalOverlay" class="modal-overlay"></div>
    <div id="modal" class="modal">
        <h2 id="modalTitle"></h2>
        <div id="modalContent"></div>
		<div id="editTopics"></div>
        <button onclick="closePopup()">Cancel</button>
        <button id="modalSave">Save</button>
    </div>
	<!-- ✅ QR Code Modal -->
	<div id="qrModal" class="qr-modal" onclick="closeQRModal()">
		<img id="qrImage">
	</div>
</body>
</html>