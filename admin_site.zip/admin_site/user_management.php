<?php
session_start();
require 'firebase_config.php'; // Ensure Firebase is configured

// Check if the user is logged in, otherwise redirect
if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_name'])) {
    header("Location: index.html");
    exit();
}

$adminName = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
	<link rel="stylesheet" href="userstyles.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css">

    <!-- Firebase SDK for Firestore -->
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-firestore.js"></script>
	<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-storage.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js"></script>
    
    <script>
        // Firebase Configuration
        const firebaseConfig = {
            apiKey: "AIzaSyC1Y7dJKv5dOBKGkMf_KYS8FNMLxwFjJyE",
            authDomain: "compmed-ar.firebaseapp.com",
            projectId: "compmed-ar",
            storageBucket: "compmed-ar.appspot.com",
            messagingSenderId: "523184550566",
            appId: "1:523184550566:android:a540c878273f0f1b067a67",
            measurementId: "G-E6GVGHKWDP"
        };

		// Initialize Firebase if it's not already initialized
		if (!firebase.apps.length) {
			firebase.initializeApp(firebaseConfig);  // Your Firebase config here
		} else {
			firebase.app();  // Use the already initialized app
		}

		// Correct reference for Firestore and Storage
		const db = firebase.firestore();
		const storage = firebase.storage(); // Make sure you're using the correct reference for storage
    </script>
</head>
<body>
	<button id="dashboardBtn" onclick="goToDashboard()">⬅ Return to Dashboard</button>
    <h2>User Management Dashboard</h2>

    <div>
        <!-- Search User -->
        <input type="text" id="searchQuery" placeholder="Search by email" />
        <button onclick="searchUser()">Search</button>
    </div>

    <!-- User Table -->
	<table id="userTable">
		<thead>
			<tr>
				<th>Profile</th> <!-- New Column for User Image -->
				<th>Name</th>
				<th>Email</th>
				<th>Status</th>
				<th>Study Course</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody></tbody>
	</table>

	<!-- Edit User Modal -->
	<div id="editModal" class="modal">
		<div class="modal-content">
			<!-- Close Button -->
			<button class="close-button" onclick="closeEditModal()">✖</button>

			<h3>Edit User Information</h3>

			<div class="edit-container">
				<!-- Left Side: Form Inputs -->
				<div class="edit-left">
					<label for="editFirstName">First Name:</label>
					<input type="text" id="editFirstName" placeholder="Enter first name" required>

					<label for="editLastName">Last Name:</label>
					<input type="text" id="editLastName" placeholder="Enter last name" required>

					<label for="editProfileImage">Profile Image:</label>
					<input type="file" id="editProfileImage" accept="image/*">

					<label for="editStudyCourse">Study Course:</label>
					<input type="text" id="editStudyCourse" placeholder="Enter study course" required>
				</div>
			<!-- Save Button -->
			<button id="saveChangesBtn" class="save-button" onclick="saveUserChanges()">Save Changes</button>
		</div>
		<br>
	</div>

	
	<!-- Modal for Image Cropper -->
		<div id="imageCropperModal" class="modal">
			<div class="modal-content">
				<button class="close-button" onclick="closeCropperModal()">❌</button>
				<h3>Crop Image</h3>
				<div>
					<img id="imagePreview" src="" alt="Profile Image Preview">
				</div>
				<button id="saveCroppedImageBtn" onclick="saveCroppedImage()">Save Cropped Image</button>
			</div>
		</div>

    <script>
		// Fetch users from Firestore and populate the table
		async function fetchUsers() {
			const userTable = document.getElementById("userTable").getElementsByTagName("tbody")[0];
			userTable.innerHTML = ''; // Clear existing table data

			const querySnapshot = await db.collection("users").get();
			querySnapshot.forEach(doc => {
				const userData = doc.data();
				const row = userTable.insertRow();

				// Profile Image Column
				const imgCell = row.insertCell(0);
				const imgElement = document.createElement("img");
				imgElement.src = userData.profile_image_url || "default-profile.png"; // Use a default image if not available
				imgElement.classList.add("profile-image");
				imgCell.appendChild(imgElement);

				// Other User Details
				row.insertCell(1).textContent = `${userData.first_name} ${userData.last_name}`;
				row.insertCell(2).textContent = userData.email;
				row.insertCell(3).textContent = userData.status;  // Display user status
				row.insertCell(4).textContent = userData.study_course;

				// Action Buttons (Without Ban/Unban)
				const actionCell = row.insertCell(5);
				actionCell.innerHTML = `
					<button class="edit-btn" onclick="editUser('${doc.id}')">Edit</button>
					<button class="delete-btn" onclick="deleteUser('${doc.id}')">Delete</button>
				`;
			});
		}

		// Remove the toggleBanUser function since it's no longer needed
		// async function toggleBanUser(userId, currentStatus) {
		//   const newStatus = currentStatus === "Active" ? "Banned" : "Active";
		//   try {
		//     await db.collection("users").doc(userId).update({ status: newStatus });
		//     alert(`User has been ${newStatus === "Banned" ? "banned" : "unbanned"} successfully.`);
		//     fetchUsers(); // Refresh user list
		//   } catch (error) {
		//     console.error("Error updating user status:", error);
		//     alert("Failed to update user status. Please try again.");
		//   }
		// }

        // Fetch users on page load
        window.onload = fetchUsers;

		// Search users by email
		async function searchUser() {
			const query = document.getElementById("searchQuery").value.trim();
			const userTable = document.getElementById("userTable").getElementsByTagName("tbody")[0];
			userTable.innerHTML = ''; // Clear existing table data

			if (query === "") {
				fetchUsers(); // Reload all users if search is empty
				return;
			}

			const querySnapshot = await db.collection("users").where("email", "==", query).get();

			if (querySnapshot.empty) {
				alert("No user found with this email.");
				fetchUsers(); // Reload users if no match found
				return;
			}

			querySnapshot.forEach(doc => {
				const userData = doc.data();
				const row = userTable.insertRow();

				// Profile Image
				const profileCell = row.insertCell(0);
				const profileImage = document.createElement("img");
				profileImage.src = userData.profile_image_url || "default-profile.png"; // Default if no profile image
				profileImage.style.width = "50px";
				profileImage.style.height = "50px";
				profileImage.style.borderRadius = "50%"; // Ensures a circular profile picture
				profileCell.appendChild(profileImage);

				row.insertCell(1).textContent = `${userData.first_name} ${userData.last_name}`;
				row.insertCell(2).textContent = userData.email;
				row.insertCell(3).textContent = userData.status;
				row.insertCell(4).textContent = userData.study_course;

				// Determine Ban/Unban Button
				const actionCell = row.insertCell(5);
				const banButtonText = userData.status === "Active" ? "Ban" : "Unban";
				const banButtonColor = userData.status === "Active" ? "red" : "green";

				actionCell.innerHTML = `
					<button onclick="editUser('${doc.id}')">Edit</button>
					<button onclick="deleteUser('${doc.id}')">Delete</button>
				`;
			});
		}

		let currentUserId = "";

		// Function to open the edit modal and populate it with user data
		function editUser(userId) {
			currentUserId = userId;

			// Get user data from Firestore
			db.collection("users").doc(userId).get().then(doc => {
				const userData = doc.data();

				// Populate modal with current user data
				document.getElementById("editFirstName").value = userData.first_name;
				document.getElementById("editLastName").value = userData.last_name;
				document.getElementById("editStudyCourse").value = userData.study_course;

				// Display the modal
				document.getElementById("editModal").style.display = "flex";
			});
		}

		// Function to close the edit modal
		function closeEditModal() {
			document.getElementById("editModal").style.display = "none";
		}

		let cropper;
		let croppedImageUrl;

		// Handle file input for profile image
		document.getElementById("editProfileImage").addEventListener("change", function(event) {
			const file = event.target.files[0];
			if (file) {
				const reader = new FileReader();
				reader.onload = function(e) {
					// Open the cropper modal
					document.getElementById("imageCropperModal").style.display = "flex";
					const image = document.getElementById("imagePreview");
					image.src = e.target.result;

					// Initialize the cropper with 1:1 ratio
					if (cropper) {
						cropper.destroy();  // Destroy previous cropper instance if it exists
					}
					cropper = new Cropper(image, {
						aspectRatio: 1, // 1:1 ratio
						viewMode: 2,  // Restrict to the container size
						minContainerWidth: 300,
						minContainerHeight: 300,
						zoomable: true,
						scalable: true,
					});
				};
				reader.readAsDataURL(file);
			}
		});

		// Close the cropper modal
		function closeCropperModal() {
			document.getElementById("imageCropperModal").style.display = "none";
			if (cropper) {
				cropper.destroy();  // Destroy cropper instance when modal is closed
			}
		}

		let croppedImageFile = null;  // Global variable to hold cropped image
		// Save the cropped image
		function saveCroppedImage() {
			const canvas = cropper.getCroppedCanvas();
			if (canvas) {
				// Compress image before uploading
				canvas.toBlob((blob) => {
					croppedImageFile = new File([blob], "profile_image.jpg", {
						type: "image/jpeg",
						lastModified: Date.now(),
					});
					alert("Profile image cropped successfully! You can now save the changes.");
				}, "image/jpeg", 0.7); // Compress the image to 70% quality
			}
		}
		
		// Function to upload the image to Firebase Storage
		async function uploadToFirebase(imageFile) {
			const storageRef = storage.ref(`user_profiles/${imageFile.name}`); // Reference to Firebase Storage
			const uploadTask = storageRef.put(imageFile); // Upload file

			uploadTask.on('state_changed', (snapshot) => {
				// Optionally handle upload progress here
			}, (error) => {
				console.error("Error uploading image: ", error);
			}, async () => {
				const downloadURL = await uploadTask.snapshot.ref.getDownloadURL(); // Get the download URL
				alert("Profile image uploaded successfully!");

				// Update the Firestore user document with the new profile image URL
				const userId = firebase.auth().currentUser.uid;
				await db.collection("users").doc(userId).update({
					profile_image_url: downloadURL,
				});

				console.log("Profile image URL updated in Firestore:", downloadURL);
			});
		}

		async function saveUserChanges() {
			const newFirstName = document.getElementById("editFirstName").value;
			const newLastName = document.getElementById("editLastName").value;
			const newStudyCourse = document.getElementById("editStudyCourse").value;
			const newProfileImage = document.getElementById("editProfileImage").files[0]; // For profile image
			let updatedData = {
				first_name: newFirstName,
				last_name: newLastName,
				study_course: newStudyCourse
			};

			const saveButton = document.getElementById("saveChangesBtn");
			saveButton.disabled = true;
			saveButton.textContent = "Saving... ⏳";

			try {
				const docRef = db.collection("users").doc(currentUserId);
				const doc = await docRef.get();

				if (!doc.exists) {
					alert("User not found.");
					return;
				}

				const oldData = doc.data(); // Fetch the old user data

				// If a new profile image is provided, compress, delete the old image, and upload the new one
				if (croppedImageFile) {
					const oldProfileImageUrl = oldData.profile_image_url;
					
					// Delete the old profile image from Firebase Storage (if it exists)
					if (oldProfileImageUrl) {
						const oldProfileImageRef = storage.refFromURL(oldProfileImageUrl);
						await oldProfileImageRef.delete(); // Delete the old image
						console.log("Old profile image deleted.");
					}

					// Create a unique name for the new image using the timestamp
					const uniqueImageName = `${currentUserId}_profile_image_${Date.now()}.jpg`;
					const profileImageRef = storage.ref(`user_profiles/${uniqueImageName}`);

					// Upload the new profile image
					const uploadTask = await profileImageRef.put(croppedImageFile);
					updatedData.profile_image_url = await uploadTask.ref.getDownloadURL();
				}

				// Update Firestore with the new user data (including the profile image URL)
				await docRef.update(updatedData);
				alert("User information updated successfully!");

				// Refresh the user list and close the modal
				fetchUsers();
				closeEditModal();
			} catch (error) {
				console.error("Error updating user:", error);
				alert("Failed to update user. Please try again.");
			} finally {
				saveButton.disabled = false;
				saveButton.textContent = "Save Changes"; // Reset button text
			}
		}

        // Delete user
      // async function deleteUser(userId) {
           // await db.collection("users").doc(userId).delete();
           // alert("User deleted successfully.");
           // fetchUsers(); // Refresh user list
       // }

        // Ban user
        // async function banUser(userId) {
            // await db.collection("users").doc(userId).update({ status: "Banned" });
            // alert("User banned successfully.");
           // fetchUsers(); // Refresh user list
       // }

        // Unban user
       // async function unbanUser(userId) {
           // await db.collection("users").doc(userId).update({ status: "Active" });
           // alert("User unbanned successfully.");
           // fetchUsers(); // Refresh user list
       // }
		
		function goToDashboard() {
			window.location.href = "dashboard.php"; // Adjust the path if necessary
		}
    </script>
</body>
</html>
