<?php
session_start();

if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_name'])) {
    header("Location: index.html");
    exit();
}

$adminName = htmlspecialchars($_SESSION['user_name']); // Safely escape the name
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quiz Page - CompMed AR</title>
  <script src="https://www.gstatic.com/firebasejs/9.15.0/firebase-app-compat.js"></script>
  <script src="https://www.gstatic.com/firebasejs/9.15.0/firebase-firestore-compat.js"></script>
  <script src="https://www.gstatic.com/firebasejs/9.15.0/firebase-storage-compat.js"></script>
  <script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
    body { background-color: #f4f7fa; color: #333; margin: 0; padding: 20px; }
    .container { width: 100%; max-width: 900px; margin: 50px auto; padding: 20px; background-color: #fff; border-radius: 12px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05); }
    .title-container { text-align: center; margin-bottom: 20px; }
    .title-container h2 { font-size: 24px; font-weight: 700; color: #2c3e50; margin-bottom: 15px; }
    input { padding: 12px; width: 100%; font-size: 16px; font-weight: 400; border: 1px solid #d1d9e0; border-radius: 6px; color: #4b5e71; background: #fff; transition: border-color 0.3s ease; }
    input:focus { border-color: #3498db; outline: none; box-shadow: 0 0 5px rgba(52, 152, 219, 0.3); }
    .question-container { position: relative; background: #fff; border: 1px solid #e5e7eb; padding: 20px; padding-top: 60px; margin: 30px 0; border-radius: 12px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05); }
    .question-number { position: absolute; top: -12px; left: 15px; background: #3498db; color: #fff; padding: 4px 12px; border-radius: 12px; font-size: 14px; font-weight: 600; }
    .model-selector { margin: 15px 0; width: 100%; padding: 10px; border: 1px solid #d1d9e0; border-radius: 6px; font-size: 16px; font-weight: 400; color: #4b5e71; background: #fff; cursor: pointer; transition: border-color 0.3s ease; }
    .model-selector:focus { border-color: #3498db; outline: none; box-shadow: 0 0 5px rgba(52, 152, 219, 0.3); }
    .model-container { position: relative; width: 100%; height: 400px; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; background: #f8fafc; }
    model-viewer { width: 100%; height: 100%; background-color: #f8fafc; }
    .loading { text-align: center; padding: 20px; color: #7b8a9b; font-size: 14px; font-weight: 400; }
    .button-container { display: flex; justify-content: space-between; margin-top: 20px; gap: 10px; }
    button { padding: 10px 20px; background-color: #4CAF50; color: #fff; border: none; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; transition: background 0.3s ease; }
    button:hover { background-color: #45a049; }
    button:disabled { background-color: #7b8a9b; cursor: not-allowed; }
    .question-actions { display: flex; justify-content: space-between; align-items: center; margin-top: 15px; }
    .navigation { display: flex; gap: 10px; }
    .delete-btn { background-color: #e74c3c; padding: 8px 16px; }
    .delete-btn:hover { background-color: #c0392b; }
    .add-annotation-btn { background-color: #3498db; padding: 8px 16px; }
    .add-annotation-btn:hover { background-color: #2980b9; }
    .annotation { display: block; margin-top: 5px; padding: 5px; width: 90%; border: 1px solid #d1d9e0; border-radius: 4px; font-size: 14px; color: #4b5e71; background: #fff; }
    .annotation-marker { background-color: #e74c3c; border: none; border-radius: 50%; width: 15px; height: 15px; cursor: pointer; color: #fff; text-align: center; line-height: 15px; font-size: 10px; }
    .delete-annotation { background: none; border: none; color: #e74c3c; cursor: pointer; padding: 4px; margin-left: 8px; font-size: 14px; opacity: 0.7; }
    .delete-annotation:hover { opacity: 1; }
    .annotation-container { position: absolute; display: flex; align-items: center; pointer-events: auto; transform: translateY(-50%); background: transparent; padding: 0; margin-left: 25px; }
    .annotation-input { background: #fff; border: 1px solid #d1d9e0; border-radius: 4px; padding: 4px 8px; font-size: 14px; width: 150px; height: 24px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); color: #4b5e71; }
    .annotation-sphere { display: inline-block; animation: pulse 2s infinite; }
    @keyframes pulse { 0% { opacity: 0.7; } 50% { opacity: 1; } 100% { opacity: 0.7; } }
    .button-group { position: absolute; top: 15px; right: 15px; display: flex; gap: 10px; }
    model-viewer::part(default-progress-mask), model-viewer::part(default-progress-bar) { display: none; }
    .status-modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.6); justify-content: center; align-items: center; z-index: 1000; }
    .status-modal-content { background: #fff; padding: 20px; border-radius: 12px; max-width: 500px; width: 90%; max-height: 70vh; overflow-y: auto; box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1); position: relative; text-align: left; }
    .status-modal-content h3 { font-size: 20px; font-weight: 600; color: #2c3e50; margin-bottom: 15px; }
    .status-modal-content p { font-size: 14px; font-weight: 400; color: #4b5e71; white-space: pre-wrap; }
    .status-modal-content.success h3 { color: #3c763d; }
    .status-modal-content.error h3 { color: #a94442; }
    .status-modal-close { position: absolute; top: 15px; right: 15px; background: #fff; border-radius: 50%; width: 30px; height: 30px; display: flex; justify-content: center; align-items: center; cursor: pointer; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); transition: background 0.3s ease; }
    .status-modal-close:hover { background: #f8fafc; }
    .status-modal-close span { font-size: 20px; font-weight: 700; color: #7b8a9b; }
    .status-modal-close:hover span { color: #e74c3c; }
  </style>
</head>
<body>

  <div class="container">
    <div class="title-container">
      <h2>Create 3D puzzle quiz</h2>
      <input type="text" id="quizTitle" placeholder="Enter Quiz Title" />
    </div>

    <div id="questions-section">
      <!-- Questions will be added here dynamically -->
    </div>

    <div class="button-container">
      <button id="add-question">Add Question</button>
      <button id="save-to-firebase">Save Quiz</button>
    </div>

    <div id="statusModal" class="status-modal">
      <div id="statusModalContent" class="status-modal-content">
        <div class="status-modal-close" onclick="closeStatusModal()">
          <span>×</span>
        </div>
        <h3 id="statusModalTitle"></h3>
        <p id="statusModalMessage"></p>
      </div>
    </div>
  </div>

  <script>
    const firebaseConfig = {
      apiKey: "AIzaSyBgr1QE4Wp8FCqi9HR6yVlh0",
      authDomain: "compmed-ar.firebaseapp.com",
      databaseURL: "https://compmed-ar-default-rtdb.asia-southeast1.firebasedatabase.app/",
      projectId: "compmed-ar",
      storageBucket: "compmed-ar.appspot.com",
      messagingSenderId: "523184550566",
      appId: "1:523184550566:web:8d617dfcc526ed6c067a67",
      measurementId: "G-E6GVGHKWDP"
    };

    firebase.initializeApp(firebaseConfig);
    const db = firebase.firestore();
    const storage = firebase.storage();

    let questionCounter = 0;
    let currentQuestion = 0;
    const questions = [];
    let modelsList = [];

    async function loadModelsList() {
      try {
        const modelsRef = storage.ref('plain3Dmodels');
        const modelFiles = await modelsRef.listAll();
        
        modelsList = await Promise.all(
          modelFiles.items.map(async (item) => {
            return {
              name: item.name,
              path: item.fullPath,
              url: await item.getDownloadURL()
            };
          })
        );
      } catch (error) {
        console.error("Error loading models list:", error);
        showStatus('Error loading 3D models', true);
      }
    }

    function createModelSelector(index, selectedModel = '') {
      const selector = document.createElement('select');
      selector.className = 'model-selector';
      selector.innerHTML = ` 
        <option value="">Select a 3D Model</option>
        ${modelsList.map(model => `
          <option value="${model.url}" ${model.url === selectedModel ? 'selected' : ''}>
            ${model.name}
          </option>
        `).join('')}`;
      
      selector.onchange = async (e) => {
        const modelUrl = e.target.value;
        questions[index].modelUrl = modelUrl;
        updateModelViewer(index, modelUrl);
      };
      
      return selector;
    }


    function updateModelViewer(index, modelUrl) {
      const modelContainer = document.getElementById(`model-container-${index}`);
      if (!modelUrl) {
        modelContainer.innerHTML = '<div class="loading">No model selected</div>';
        return;
      }
      
      modelContainer.innerHTML = `  
        <model-viewer
          id="model-viewer-${index}"
          src="${modelUrl}"
          auto-rotate
          camera-controls
          ar
          ar-modes="webxr scene-viewer quick-look"
          shadow-intensity="1"
          camera-orbit="45deg 55deg 2.5m"
          exposure="0.2"
          loading="lazy">
        </model-viewer>
      `;

      const modelViewer = document.getElementById(`model-viewer-${index}`);
      
      modelViewer.addEventListener('click', (event) => {
        handleModelClick(index, event);
      });

      if (questions[index].annotations) {
        questions[index].annotations.forEach(annotation => {
          const annotationGroup = document.createElement('div');
          annotationGroup.setAttribute('slot', `hotspot-${annotation.id}`);
          annotationGroup.style.transform = 'translateX(-50%)';
          
          const sphere = document.createElement('div');
          sphere.classList.add('annotation-sphere');
          sphere.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 20 20">
              <defs>
                <radialGradient id="sphere-gradient-${annotation.id}" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                  <stop offset="0%" style="stop-color:rgb(255,50,50);stop-opacity:1" />
                  <stop offset="100%" style="stop-color:rgb(200,0,0);stop-opacity:1" />
                </radialGradient>
              </defs>
              <circle cx="10" cy="10" r="10" fill="url(#sphere-gradient-${annotation.id})" />
            </svg>
          `;

          const annotationContainer = document.createElement('div');
          annotationContainer.className = 'annotation-container';
          
          const input = document.createElement('input');
          input.type = 'text';
          input.className = 'annotation-input';
          input.placeholder = 'Enter description...';
          input.value = annotation.description || '';
          
          const deleteButton = document.createElement('button');
          deleteButton.className = 'delete-annotation';
          deleteButton.innerHTML = '×';
          deleteButton.title = 'Delete annotation';
          deleteButton.onclick = () => removeAnnotation(index, annotation.id);

          input.addEventListener('input', (e) => {
            annotation.description = e.target.value;
          });

          annotationGroup.setAttribute('data-position', `${annotation.x} ${annotation.y} ${annotation.z}`);
          annotationGroup.setAttribute('data-normal', `${annotation.nx} ${annotation.ny} ${annotation.nz}`); // Use nx, ny, nz

          annotationContainer.appendChild(input);
          annotationContainer.appendChild(deleteButton);
          annotationGroup.appendChild(sphere);
          annotationGroup.appendChild(annotationContainer);
          
          modelViewer.appendChild(annotationGroup);
        });
      }
    }

    function removeAnnotation(index, annotationId) {
      const modelViewer = document.getElementById(`model-viewer-${index}`);
      const annotationGroup = modelViewer.querySelector(`[slot="hotspot-${annotationId}"]`);
      
      if (annotationGroup) {
        annotationGroup.remove();
        questions[index].annotations = questions[index].annotations.filter(
          annotation => annotation.id !== annotationId
        );
      }
    }

    let isAnnotationModeEnabled = false;

    function enableAnnotationMode(index) {
      isAnnotationModeEnabled = !isAnnotationModeEnabled;
      const annotationButton = document.getElementById(`add-annotation-${index}`);
      annotationButton.textContent = isAnnotationModeEnabled ? 'Disable Annotations' : 'Add Annotations';
    }

    function handleModelClick(index, event) {
      if (!isAnnotationModeEnabled) return;
      
      const modelViewer = document.getElementById(`model-viewer-${index}`);
      const hit = modelViewer.positionAndNormalFromPoint(event.clientX, event.clientY);

      if (hit) {
        const { position, normal } = hit;
        const annotationId = `annotation-${index}-${questions[index].annotations.length}`;
        
        const annotationGroup = document.createElement('div');
        annotationGroup.setAttribute('slot', `hotspot-${annotationId}`);
        annotationGroup.style.transform = 'translateX(-50%)';
        
        const sphere = document.createElement('div');
        sphere.classList.add('annotation-sphere');
        sphere.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 20 20">
            <defs>
              <radialGradient id="sphere-gradient-${annotationId}" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                <stop offset="0%" style="stop-color:rgb(255,50,50);stop-opacity:1" />
                <stop offset="100%" style="stop-color:rgb(200,0,0);stop-opacity:1" />
              </radialGradient>
            </defs>
            <circle cx="10" cy="10" r="10" fill="url(#sphere-gradient-${annotationId})" />
          </svg>
        `;

        const annotationContainer = document.createElement('div');
        annotationContainer.className = 'annotation-container';
        
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'annotation-input';
        input.placeholder = 'Enter description...';
        
        const deleteButton = document.createElement('button');
        deleteButton.className = 'delete-annotation';
        deleteButton.innerHTML = '×';
        deleteButton.title = 'Delete annotation';
        deleteButton.onclick = () => removeAnnotation(index, annotationId);

        input.addEventListener('input', (e) => {
          const annotation = questions[index].annotations.find(a => a.id === annotationId);
          if (annotation) {
            annotation.description = e.target.value;
          }
        });

        annotationGroup.setAttribute('data-position', `${position.x} ${position.y} ${position.z}`);
        annotationGroup.setAttribute('data-normal', `${normal.x} ${normal.y} ${normal.z}`);
        
        annotationContainer.appendChild(input);
        annotationContainer.appendChild(deleteButton);
        annotationGroup.appendChild(sphere);
        annotationGroup.appendChild(annotationContainer);
        
        modelViewer.appendChild(annotationGroup);

        questions[index].annotations.push({
          id: annotationId,
          x: position.x,
          y: position.y,
          z: position.z,
          nx: normal.x, // Add normal x
          ny: normal.y, // Add normal y
          nz: normal.z, // Add normal z
          description: ''
        });
      }
    }

    document.getElementById('add-question').addEventListener('click', () => {
      questions.push({ 
        question: '',
        modelUrl: '',
        annotations: []
      });
      questionCounter++;
      showQuestion(questions.length - 1);
    });

    function showQuestion(index) {
      currentQuestion = index;
      const questionsSection = document.getElementById('questions-section');
      questionsSection.innerHTML = '';

      if (questions[index]) {
        const questionContainer = document.createElement('div');
        questionContainer.className = 'question-container';
        questionContainer.innerHTML = `
          <div class="question-number">Question ${index + 1} of ${questions.length}</div>
          <div class="button-group">
            <button onclick="deleteQuestion(${index})" class="delete-btn">Delete Question</button>
          </div>
          <input type="text" 
                 id="question-${index}" 
                 value="${questions[index].question || ''}" 
                 placeholder="Enter your question"
                 onchange="updateQuestion(${index}, this.value)">
          <div id="model-selector-${index}"></div>
          <div id="model-container-${index}" class="model-container">
            <div class="loading">No model selected</div>
          </div>
          <div class="question-actions">
            <div class="navigation">
              <button onclick="showQuestion(${index - 1})" ${index === 0 ? 'disabled' : ''}>Previous</button>
              <button onclick="showQuestion(${index + 1})" ${index === questions.length - 1 ? 'disabled' : ''}>Next</button>
            </div>
            <button id="add-annotation-${index}" class="add-annotation-btn">Add Annotations</button>
          </div>
        `;
        questionsSection.appendChild(questionContainer);

        const selectorContainer = document.getElementById(`model-selector-${index}`);
        selectorContainer.appendChild(createModelSelector(index, questions[index].modelUrl));

        if (questions[index].modelUrl) {
          updateModelViewer(index, questions[index].modelUrl);
        }

        document.getElementById(`add-annotation-${index}`).addEventListener('click', () => {
          enableAnnotationMode(index);
        });
      }
    }

    function updateQuestion(index, value) {
      questions[index].question = value;
    }

    function deleteQuestion(index) {
      if (questions.length === 1) {
        showStatus('Cannot delete the last question!', true);
        return;
      }
      
      questions.splice(index, 1);
      if (currentQuestion >= questions.length) {
        currentQuestion = questions.length - 1;
      }
      showQuestion(currentQuestion);
    }

    function showStatus(message, isError = false) {
      const modal = document.getElementById('statusModal');
      const modalContent = document.getElementById('statusModalContent');
      const modalTitle = document.getElementById('statusModalTitle');
      const modalMessage = document.getElementById('statusModalMessage');

      modalTitle.textContent = isError ? 'Error' : 'Success';
      modalMessage.textContent = message;
      modalContent.className = `status-modal-content ${isError ? 'error' : 'success'}`;
      modal.style.display = 'flex';
    }

    function closeStatusModal() {
      const modal = document.getElementById('statusModal');
      modal.style.display = 'none';
    }

    document.getElementById('save-to-firebase').addEventListener('click', async () => {
      const title = document.getElementById('quizTitle').value.trim();

      if (!title) {
        showStatus('Please enter a quiz title!', true);
        return;
      }

      if (!questions.length) {
        showStatus('Please add at least one question!', true);
        return;
      }

      let errorMessages = [];
        questions.forEach((q, index) => {
          const qNum = index + 1;
          if (!q.question || !q.question.trim()) {
            errorMessages.push(`Question ${qNum}: Please enter a question text.`);
          }
          if (!q.modelUrl) {
            errorMessages.push(`Question ${qNum}: Please select a 3D model.`);
          }
          if (!q.annotations || q.annotations.length === 0) {
            errorMessages.push(`Question ${qNum}: No annotations marked on the 3D model. Please add at least one annotation.`);
          } else {
            q.annotations.forEach((annotation, annotIndex) => {
              if (!annotation.description || !annotation.description.trim()) {
                errorMessages.push(`Question ${qNum}, Annotation ${annotIndex + 1}: Please enter a description for the annotation.`);
              }
            });
          }
        }
      );

        if (errorMessages.length > 0) {
          showStatus(errorMessages.join('\n'), true);
          return;
        }

        const quizData = {
          quizTitle: title,
          quizType: '3Dmodel',
          timestamp: Date.now(),
        };

        try {
          const quizRef = db.collection('questions')
                            .doc('3Dmodel_question')
                            .collection('quizzes')
                            .doc();

          await quizRef.set(quizData);

          const questionsCollectionRef = quizRef.collection('3Dquestions');
          const questionsPromises = questions.map(async (q, index) => { // Added index parameter
            return questionsCollectionRef.add({
              question: q.question,
              modelUrl: q.modelUrl || '',
              questionNumber: index + 1,
              timestamp: Date.now(),
              annotations: q.annotations.map(a => ({
                id: a.id,
                x: a.x,
                y: a.y,
                z: a.z,
                nx: a.nx,
                ny: a.ny,
                nz: a.nz,
                description: a.description
              }))
            });
          });

          await Promise.all(questionsPromises);

          showStatus('Quiz saved successfully!', false);
          setTimeout(() => {
            closeStatusModal();
            window.location.href = 'quizmainpage.php';
          }, 1000);
        } catch (error) {
          console.error("Detailed error saving quiz:", error);
          showStatus(`Error saving quiz: ${error.message}`, true);
        }
      });

    async function initializeApp() {
      try {
        await loadModelsList();
        document.getElementById('add-question').click();
      } catch (error) {
        showStatus('Failed to initialize app: ' + error.message, true);
      }
    }
    initializeApp();
  </script>
</body>
</html>