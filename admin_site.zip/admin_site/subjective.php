<?php
session_start();

if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_name'])) {
    header("Location: index.html");
    exit();
}

$adminName = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Subjective Questions - CompMed AR</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/firebase/9.23.0/firebase-app-compat.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/firebase/9.23.0/firebase-firestore-compat.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: #f4f7fa; color: #333; max-width: 900px; margin: 20px auto; padding: 0 20px; line-height: 1.6; }
        h1 { font-size: 32px; font-weight: 700; color: #2c3e50; margin-bottom: 20px; }
        .quiz-header { margin-bottom: 30px; }
        .quiz-header input { width: 100%; padding: 12px; font-size: 16px; font-weight: 400; border: 1px solid #d1d9e0; border-radius: 6px; color: #4b5e71; background: #fff; transition: border-color 0.3s ease; }
        .quiz-header input:focus { border-color: #3498db; outline: none; box-shadow: 0 0 5px rgba(52, 152, 219, 0.3); }
        .question-container { position: relative; background: #fff; border: 1px solid #e5e7eb; padding: 20px; margin: 30px 0; border-radius: 12px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05); padding-top: 70px; }
        .question-number { position: absolute; top: -12px; left: 15px; background: #3498db; color: #fff; padding: 4px 12px; border-radius: 12px; font-size: 14px; font-weight: 600; }
        .marks-input, .question-input, .keywords-input { width: 100%; padding: 12px; margin: 10px 0; font-size: 16px; font-weight: 400; border: 1px solid #d1d9e0; border-radius: 6px; color: #4b5e71; background: #f8fafc; transition: border-color 0.3s ease; }
        .marks-input { width: 80px; position: absolute; top: 15px; left: 15px; }
        .marks-label { position: absolute; top: 20px; left: 100px; font-size: 14px; color: #4b5e71; }
        .question-input:focus, .keywords-input:focus, .marks-input:focus { border-color: #3498db; outline: none; box-shadow: 0 0 5px rgba(52, 152, 219, 0.3); }
        .add-button, .delete-button { padding: 10px 20px; font-size: 14px; font-weight: 600; border: none; border-radius: 6px; cursor: pointer; transition: background 0.3s ease; }
        .add-button { background: #4CAF50; color: #fff; margin-right: 10px; }
        .add-button:hover { background: #45a049; }
        .delete-button { background: #e74c3c; color: #fff; padding: 8px 16px; }
        .delete-button:hover { background: #c0392b; }
        .button-group { position: absolute; top: 15px; right: 15px; display: flex; gap: 10px; }
        .status-modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.6); justify-content: center; align-items: center; z-index: 1000; }
        .status-modal-content { background: #fff; padding: 20px; border-radius: 12px; max-width: 500px; width: 90%; max-height: 70vh; overflow-y: auto; box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1); position: relative; text-align: left; }
        .status-modal-content h3 { font-size: 20px; font-weight: 600; color: #2c3e50; margin-bottom: 15px; }
        .status-modal-content p { font-size: 14px; font-weight: 400; color: #4b5e71; white-space: pre-wrap; }
        .status-modal-content.success h3 { color: #3c763d; }
        .status-modal-content.error h3 { color: #a94442; }
        .status-modal-close { position: absolute; top: 15px; right: 15px; background: #fff; border-radius: 50%; width: 30px; height: 30px; display: flex; justify-content: center; align-items: center; cursor: pointer; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); transition: background 0.3s ease; }
        .status-modal-close:hover { background: #f8fafc; }
        .status-modal-close span { font-size: 20px; font-weight: 700; color: #7b8a9b; }
        .status-modal-close:hover span { color: #e74c3c; }
    </style>
</head>
<body>
    <h1>Create Subjective Questions</h1>
    
    <div class="quiz-header">
        <input type="text" id="quizTitle" placeholder="Enter Quiz Title" />
    </div>

    <div id="questionnaire-container"></div>
    <button onclick="addQuestion()" class="add-button">Add Question</button>
    <button onclick="saveSubjectiveQuestions()" class="add-button">Save to Firestore</button>

    <div id="statusModal" class="status-modal">
        <div id="statusModalContent" class="status-modal-content">
            <div class="status-modal-close" onclick="closeStatusModal()">
                <span>×</span>
            </div>
            <h3 id="statusModalTitle"></h3>
            <p id="statusModalMessage"></p>
        </div>
    </div>

    <script>
        let questions = [];

        const firebaseConfig = {
            apiKey: "AIzaSyBgr1QE4Wp8FCqi9HR6yVlh0", // Replace with your full Firebase API key
            authDomain: "compmed-ar.firebaseapp.com",
            databaseURL: "https://compmed-ar-default-rtdb.asia-southeast1.firebasedatabase.app/",
            projectId: "compmed-ar",
            storageBucket: "compmed-ar.appspot.com",
            messagingSenderId: "523184550566",
            appId: "1:523184550566:web:8d617dfcc526ed6c067a67",
            measurementId: "G-E6GVGHKWDP"
        };

        firebase.initializeApp(firebaseConfig);
        const db = firebase.firestore();

        function showStatus(message, isError = false) {
            const modal = document.getElementById('statusModal');
            const modalContent = document.getElementById('statusModalContent');
            const modalTitle = document.getElementById('statusModalTitle');
            const modalMessage = document.getElementById('statusModalMessage');

            modalTitle.textContent = isError ? 'Error' : 'Success';
            modalMessage.textContent = message;
            modalContent.className = `status-modal-content ${isError ? 'error' : 'success'}`;
            modal.style.display = 'flex';
        }

        function closeStatusModal() {
            const modal = document.getElementById('statusModal');
            modal.style.display = 'none';
        }

        function addQuestion() {
            questions.push({ type: 'subjective', question: '', keywords: '', marks: 1 }); // Default marks to 1
            renderQuestionnaire();
        }

        function updateQuestion(index, field, value) {
            if (field === 'marks') {
                const intValue = parseInt(value);
                questions[index][field] = isNaN(intValue) || intValue < 0 ? 0 : intValue; // Ensure non-negative integer
            } else {
                questions[index][field] = value;
            }
        }

        function deleteQuestion(index) {
            if (confirm(`Are you sure you want to delete Question ${index + 1}?`)) {
                questions.splice(index, 1);
                renderQuestionnaire();
                showStatus(`Question ${index + 1} deleted successfully!`);
            }
        }

        async function saveSubjectiveQuestions() {
            const title = document.getElementById('quizTitle').value.trim();
            if (!title) {
                showStatus('Please enter a quiz title!', true);
                return;
            }

            if (!questions.length) {
                showStatus('Please add at least one question!', true);
                return;
            }

            let errorMessages = [];
            questions.forEach((q, index) => {
                const qNum = index + 1;
                if (!q.question.trim()) {
                    errorMessages.push(`Question ${qNum}: Please enter a question text.`);
                }
                if (!q.keywords.trim()) {
                    errorMessages.push(`Question ${qNum}: Please enter keywords for auto-marking.`);
                }
                if (q.marks === null || q.marks === undefined || q.marks < 0) {
                    errorMessages.push(`Question ${qNum}: Please enter a valid non-negative integer for marks.`);
                }
            });

            if (errorMessages.length > 0) {
                showStatus(errorMessages.join('\n'), true);
                return;
            }

            try {
                const quizRef = db.collection('questions')
                    .doc('subjective_question')
                    .collection('quizzes')
                    .doc();

                const quizData = {
                    quizTitle: title,
                    quizType: 'subjective',
                    timestamp: Date.now(),
                };

                await quizRef.set(quizData);

                const subjectiveQuestionsRef = quizRef.collection('questions');
                const questionPromises = questions.map(async (q, index) => {
                    const questionData = {
                        questionText: q.question,
                        questionNumber: index + 1,
                        keywords: q.keywords.split(',').map(k => k.trim().toLowerCase()),
                        marks: q.marks, // Save marks as integer
                        timestamp: Date.now(),
                    };
                    return subjectiveQuestionsRef.add(questionData);
                });

                await Promise.all(questionPromises);

                showStatus('Subjective quiz saved successfully!');
                setTimeout(() => {
                    window.location.href = 'quizmainpage.php';
                    closeStatusModal();
                }, 1000);
            } catch (error) {
                showStatus('Error saving quiz: ' + error.message, true);
            }
        }

        function renderQuestionnaire() {
            const container = document.getElementById('questionnaire-container');
            container.innerHTML = questions.map((q, qIndex) => `
                <div class="question-container">
                    <div class="question-number">Question ${qIndex + 1}</div>
                    <div class="button-group">
                        <button onclick="deleteQuestion(${qIndex})" class="delete-button">Delete Question</button>
                    </div>
                    <input 
                        type="number" 
                        class="marks-input" 
                        min="1" 
                        value="${q.marks}" 
                        onchange="updateQuestion(${qIndex}, 'marks', this.value)"
                    >
                    <span class="marks-label">Marks</span>
                    <input 
                        type="text" 
                        class="question-input"
                        placeholder="Enter question"
                        value="${q.question}"
                        onchange="updateQuestion(${qIndex}, 'question', this.value)"
                    >
                    <input 
                        type="text" 
                        class="keywords-input"
                        placeholder="Enter keywords (comma-separated, e.g., heart, blood, pump)"
                        value="${q.keywords}"
                        onchange="updateQuestion(${qIndex}, 'keywords', this.value)"
                    >
                </div>
            `).join('');
        }

        addQuestion();
    </script>
</body>
</html>