<?php
session_start();

if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_name'])) {
    header("Location: index.html");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<link rel="shortcut icon" href="#" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Management</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
	<script src="https://www.gstatic.com/firebasejs/9.6.10/firebase-app-compat.js"></script>
	<script src="https://www.gstatic.com/firebasejs/9.6.10/firebase-auth-compat.js"></script>
	<script src="https://www.gstatic.com/firebasejs/9.6.10/firebase-firestore-compat.js"></script>
	<script src="https://www.gstatic.com/firebasejs/9.6.10/firebase-storage-compat.js"></script>
	<script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
	<link rel="stylesheet" href="organstyles.css">
</head>

<body>
<button class="button-3" onclick="window.location.href='dashboard.php'">Return to Dashboard</button>
	<div class="container">
		<h1>3D Organ Management</h1>
		<form id="uploadForm" class="upload-form">
			<input type="text" id="modelName" placeholder="Model Name" required>
			<textarea id="modelDescription" placeholder="Model Description" rows="4" required></textarea>
			
			<!-- Model File Upload -->
			<label for="modelFile">Select 3D Model File:</label>
			<input type="file" id="modelFile" accept=".glb,.gltf" required onchange="previewModel(event)">

			<label for="webarURL">Web AR Link (Optional):</label>
			<textarea id="webarURL" placeholder="Enter Web AR Link (e.g., https://mywebar.com/p/model)" rows="2"></textarea>

			<!-- Model Preview -->
			<div id="modelPreviewContainer" style="display: none;">
				<h3>3D Model Preview</h3>
				<model-viewer id="modelPreview" src="" alt="3D Model Preview" auto-rotate camera-controls></model-viewer>
			</div>

			<!-- ✅ Added Preview Image Upload Section -->
			<label for="previewImage">Select Preview Image:</label>
			<input type="file" id="previewImage" accept="image/*" required onchange="previewImage(event)">
			
			<!-- ✅ Added Preview Image Display -->
			<div id="previewImageContainer" style="display: none;">
				<h3>Preview Image</h3>
				<img id="previewImageElement" src="" alt="Preview Image" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px;">
			</div>

			<!-- Upload Progress -->
			<div id="progressContainer" style="display: none;">
				<progress id="uploadProgress" value="0" max="100"></progress>
				<span id="progressText">0%</span>
			</div>

			<!-- Upload Button -->
			<button type="button" onclick="uploadModel()">Upload Model</button>
		</form>

		<br><br><br><br>
		<h3>Uploaded Models</h3>
		<div id="modelContainer"></div>
	</div>
	
<script>
    const firebaseConfig = {
        apiKey: "AIzaSyC1Y7dJKv5dOBKGkMf_KYS8FNMLxwFjJyE",
        authDomain: "compmed-ar.firebaseapp.com",
        projectId: "compmed-ar",
        storageBucket: "compmed-ar.appspot.com",
        messagingSenderId: "523184550566",
        appId: "1:523184550566:android:a540c878273f0f1b067a67",
        measurementId: "G-E6GVGHKWDP"
    };

    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);

    // Initialize Authentication, Firestore, and Storage
    const auth = firebase.auth();
    const db = firebase.firestore();
    const storage = firebase.storage();

    // Listen for authentication state changes
    auth.onAuthStateChanged((user) => {
        if (user) {
            console.log("User signed in:", user.email);
            fetchModels(); // Fetch models when the user is authenticated
        } else {
            alert("You must be signed in to view models.");
        }
    });

async function uploadModel() {
    const modelName = document.getElementById("modelName").value;
    const modelDescription = document.getElementById("modelDescription").value;
    const modelFile = document.getElementById("modelFile").files[0];
    const previewImageFile = document.getElementById("previewImage").files[0];
    const webarURL = document.getElementById("webarURL").value; // New: Get the web URL
    const progressContainer = document.getElementById("progressContainer");
    const uploadProgress = document.getElementById("uploadProgress");
    const progressText = document.getElementById("progressText");

    if (!modelName || !modelDescription || !modelFile || !previewImageFile) {
        alert("Please fill in all fields and select both a model file and a preview image.");
        return;
    }

    try {
        // Show the progress bar
        progressContainer.style.display = "block";

        // Upload the model file to Firebase Storage with progress tracking
        const modelStorageRef = firebase.storage().ref(`3dmodels/${modelFile.name}`);
        const modelUploadTask = modelStorageRef.put(modelFile);

        modelUploadTask.on(
            "state_changed",
            (snapshot) => {
                // Update the progress bar
                const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                uploadProgress.value = progress;
                progressText.textContent = `${Math.floor(progress)}%`;
            },
            (error) => {
                console.error("Error uploading model:", error.message);
                alert("Failed to upload model. Please try again.");
                progressContainer.style.display = "none";
            },
            async () => {
                // Model Upload Completed
                const fileURL = await modelUploadTask.snapshot.ref.getDownloadURL();
                console.log("Model File URL retrieved:", fileURL);

                // Upload Preview Image to Firebase Storage
                const previewStorageRef = firebase.storage().ref(`preview_images/${previewImageFile.name}`);
                await previewStorageRef.put(previewImageFile);
                const previewURL = await previewStorageRef.getDownloadURL();
                console.log("Preview Image URL retrieved:", previewURL);

                // Save model information in Firestore, including webarURL
                await db.collection("3dmodels").add({
                    name: modelName,
                    description: modelDescription,
                    fileName: modelFile.name,
                    fileURL: fileURL,
                    previewImage: previewURL,
                    webarURL: webarURL || "", // New: Add webarURL (empty string if not provided)
                    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                });

                alert("Model uploaded successfully!");
                document.getElementById("uploadForm").reset();
                document.getElementById("modelPreviewContainer").style.display = "none";

                // Reset the progress bar
                progressContainer.style.display = "none";
                uploadProgress.value = 0;
                progressText.textContent = "0%";

                fetchModels(); // Refresh the list
            }
        );
    } catch (error) {
        console.error("Error uploading model:", error.message);
        alert("Failed to upload model. Please try again.");
        progressContainer.style.display = "none";
    }
}

async function fetchModels() {
    const modelContainer = document.getElementById("modelContainer");
    modelContainer.innerHTML = ""; // Clear the container

    try {
        const querySnapshot = await db.collection("3dmodels").orderBy("createdAt", "desc").get();

        if (querySnapshot.empty) {
            modelContainer.innerHTML = "<p>No models found.</p>";
            return;
        }

        querySnapshot.forEach((doc) => {
            const model = doc.data();
            const modelItem = document.createElement("div");
            modelItem.classList.add("model-item");

            // Model Details
            const displayInfo = document.createElement("div");
            displayInfo.classList.add("model-display");

            const nameDisplay = document.createElement("p");
            nameDisplay.textContent = model.name;
            nameDisplay.classList.add("model-name");

            const descriptionDisplay = document.createElement("p");
            descriptionDisplay.textContent = model.description;
            descriptionDisplay.classList.add("model-description");

            const fileNameDisplay = document.createElement("p");
            fileNameDisplay.textContent = `Current File: ${model.fileName}`;
            fileNameDisplay.classList.add("model-file-name");

            // Remove this block to hide the Web AR Link in the default view
            /*
            let webarURLDisplay = null;
            if (model.webarURL) {
                webarURLDisplay = document.createElement("p");
                webarURLDisplay.textContent = `Web AR Link: ${model.webarURL}`;
                webarURLDisplay.classList.add("model-web-url");
                displayInfo.appendChild(webarURLDisplay);
            }
            */

            // ✅ **Preview Image Display**
            const previewImage = document.createElement("img");
            previewImage.src = model.previewImage || "default_preview.jpg"; // Use default if no preview available
            previewImage.classList.add("preview-image");
            previewImage.style.width = "100px";
            previewImage.style.height = "100px";
            previewImage.style.objectFit = "cover";
            previewImage.style.borderRadius = "8px";
            previewImage.style.marginBottom = "10px";

            // Editable Inputs
            const nameInput = document.createElement("input");
            nameInput.type = "text";
            nameInput.value = model.name;
            nameInput.style.display = "none";

            const descriptionInput = document.createElement("textarea");
            descriptionInput.rows = 5;
            descriptionInput.value = model.description;
            descriptionInput.style.display = "none";
			descriptionInput.style.marginBottom = "15px";

            // New: Add a label for the webarURL input (still used in edit mode)
            const webarURLLabel = document.createElement("label");
            webarURLLabel.textContent = "Update Web AR Link:";
            webarURLLabel.style.display = "none"; // Initially hidden

            const webarURLInput = document.createElement("textarea");
            webarURLInput.rows = 2;
            webarURLInput.value = model.webarURL || ""; // Set the value to the current webarURL or empty string
            webarURLInput.style.display = "none"; // Initially hidden
			webarURLInput.style.marginBottom = "15px";

            // ✅ **Added Labels for File Inputs**
            const modelFileLabel = document.createElement("label");
            modelFileLabel.textContent = "Update 3D Model File:";
            modelFileLabel.style.display = "none";

            const fileInput = document.createElement("input");
            fileInput.type = "file";
            fileInput.accept = ".glb,.gltf";
            fileInput.style.display = "none";
			fileInput.style.marginBottom = "15px";

            const previewFileLabel = document.createElement("label");
            previewFileLabel.textContent = "Update Preview Image:";
            previewFileLabel.style.display = "none";

            const previewInput = document.createElement("input");
            previewInput.type = "file";
            previewInput.accept = "image/*";
            previewInput.style.display = "none";

            // Buttons
            const buttonContainer = document.createElement("div");
            buttonContainer.classList.add("button-container");

            const editButton = document.createElement("button");
            editButton.textContent = "Edit";
            editButton.onclick = () => {
                nameDisplay.style.display = "none";
                descriptionDisplay.style.display = "none";
                fileNameDisplay.style.display = "none";

                nameInput.style.display = "block";
                descriptionInput.style.display = "block";
                webarURLLabel.style.display = "block"; // Show the webarURL label
                webarURLInput.style.display = "block"; // Show the webarURL input

                // ✅ Show Labels and Inputs when Editing
                modelFileLabel.style.display = "block";
                fileInput.style.display = "block";
                previewFileLabel.style.display = "block";
                previewInput.style.display = "block";

                saveButton.style.display = "inline-block";
                cancelButton.style.display = "inline-block";
                editButton.style.display = "none";
            };

            const saveButton = document.createElement("button");
            saveButton.textContent = "Save";
            saveButton.style.display = "none";
            saveButton.onclick = async () => {
                const updatedData = {
                    name: nameInput.value,
                    description: descriptionInput.value,
                    webarURL: webarURLInput.value || "",
                };

                // ✅ **Disable Save Button & Show Loading Icon**
                saveButton.disabled = true;
                saveButton.innerHTML = "Saving... <span class='loader'></span>";

                try {
                    if (fileInput.files[0]) {
                        const newFile = fileInput.files[0];
                        const storageRef = storage.ref(`3dmodels/${newFile.name}`);
                        const uploadTask = await storageRef.put(newFile);
                        updatedData.fileURL = await uploadTask.ref.getDownloadURL();
                        updatedData.fileName = newFile.name;
                    }

                    if (previewInput.files[0]) {
                        const newPreview = previewInput.files[0];
                        const previewRef = storage.ref(`preview_images/${newPreview.name}`);
                        const previewUploadTask = await previewRef.put(newPreview);
                        updatedData.previewImage = await previewUploadTask.ref.getDownloadURL();
                    }

                    if (webarURLInput.value) {
                        updatedData.webarURL = webarURLInput.value;
                    }

                    await db.collection("3dmodels").doc(doc.id).update(updatedData);

                    // ✅ **Show Success Message & Reset Save Button**
                    saveButton.innerHTML = "✅ Saved!";
                    setTimeout(() => {
                        saveButton.innerHTML = "Save";
                        saveButton.disabled = false;
                    }, 2000);

                    fetchModels(); // Refresh the list
                } catch (error) {
                    console.error("Error updating model:", error);
                    alert("Failed to update model. Please try again.");

                    // ✅ **Re-enable Save Button on Failure**
                    saveButton.innerHTML = "Save";
                    saveButton.disabled = false;
                }
            };

            const cancelButton = document.createElement("button");
            cancelButton.textContent = "Cancel";
            cancelButton.style.display = "none";
            cancelButton.onclick = () => {
                nameDisplay.style.display = "block";
                descriptionDisplay.style.display = "block";
                fileNameDisplay.style.display = "block";

                nameInput.style.display = "none";
                descriptionInput.style.display = "none";
                webarURLLabel.style.display = "none"; // Hide the webarURL label
                webarURLInput.style.display = "none"; // Hide the webarURL input

                // ✅ Hide Labels and Inputs when Cancelling
                modelFileLabel.style.display = "none";
                fileInput.style.display = "none";
                previewFileLabel.style.display = "none";
                previewInput.style.display = "none";

                saveButton.style.display = "none";
                cancelButton.style.display = "none";
                editButton.style.display = "inline-block";
            };

            const deleteButton = document.createElement("button");
            deleteButton.textContent = "Delete";
            deleteButton.onclick = async () => {
                if (confirm("Are you sure you want to delete this model?")) {
                    await deleteModel(doc.id); // ✅ Calls the proper delete function
                }
            };

            // Append Elements
            displayInfo.appendChild(previewImage);
            displayInfo.appendChild(nameDisplay);
            displayInfo.appendChild(descriptionDisplay);
            displayInfo.appendChild(fileNameDisplay);
            // Removed appending webarURLDisplay since we don’t want to show it
            displayInfo.appendChild(nameInput);
            displayInfo.appendChild(descriptionInput);
            displayInfo.appendChild(webarURLLabel); // Append the webarURL label
            displayInfo.appendChild(webarURLInput);

            // ✅ Append Labels and Inputs
            displayInfo.appendChild(modelFileLabel);
            displayInfo.appendChild(fileInput);
            displayInfo.appendChild(previewFileLabel);
            displayInfo.appendChild(previewInput);

            buttonContainer.appendChild(editButton);
            buttonContainer.appendChild(saveButton);
            buttonContainer.appendChild(cancelButton);
            buttonContainer.appendChild(deleteButton);

            modelItem.appendChild(displayInfo);
            modelItem.appendChild(buttonContainer);
            modelContainer.appendChild(modelItem);
        });
    } catch (error) {
        console.error("Error fetching models:", error);
        alert("Failed to load models. Check the console for more details.");
    }
}
	
async function updateModel(modelId, newName, newDescription, newPreviewImageFile, newWebURL) {
    try {
        const docRef = db.collection("3dmodels").doc(modelId);
        const doc = await docRef.get();

        if (!doc.exists) {
            alert("Model not found.");
            return;
        }

        const updatedData = {
            name: newName,
            description: newDescription,
        };

        // ✅ **Handle Preview Image Update**
        if (newPreviewImageFile) {
            const previewRef = storage.ref(`preview_images/${newPreviewImageFile.name}`);
            await previewRef.put(newPreviewImageFile);
            updatedData.previewImage = await previewRef.getDownloadURL();
        }

        // ✅ **Handle Web URL Update**
        if (newWebURL !== undefined) { // Only update if a new webarURL is provided
            updatedData.webarURL = newWebURL || ""; // Use empty string if not provided
        }

        // ✅ **Update Firestore Document**
        await docRef.update(updatedData);

        alert("Model information updated successfully!");
        fetchModels(); // Refresh the model list
    } catch (error) {
        console.error("Error updating model:", error);
        alert("Failed to update model. Please try again.");
    }
}

async function deleteModel(modelId) {
    try {
        const docRef = db.collection("3dmodels").doc(modelId);
        const doc = await docRef.get();

        if (!doc.exists) {
            alert("Model not found.");
            return;
        }

        const modelData = doc.data();
        const fileURL = modelData.fileURL;
        const previewURL = modelData.previewImage;

        // ✅ Show Loading Indicator
        const loadingMessage = document.createElement("div");
        loadingMessage.id = "loading-message";
        loadingMessage.innerHTML = "<div class='spinner'></div> Deleting...";
        document.body.appendChild(loadingMessage);

        // ✅ Delete files from Firebase Storage before removing Firestore entry
        if (fileURL) {
            try {
                await storage.refFromURL(fileURL).delete();
                console.log("✅ 3D Model file deleted:", fileURL);
            } catch (error) {
                console.warn("⚠ Could not delete 3D model file:", error.message);
            }
        }

        if (previewURL) {
            try {
                await storage.refFromURL(previewURL).delete();
                console.log("✅ Preview image deleted:", previewURL);
            } catch (error) {
                console.warn("⚠ Could not delete preview image:", error.message);
            }
        }

        // ✅ Finally, delete the document from Firestore (including webarURL)
        await docRef.delete();
        console.log("✅ Firestore entry (including webarURL) deleted!");

        // ✅ Show success message
        loadingMessage.innerHTML = "✅ Model, preview image, and associated data deleted successfully!";
        setTimeout(() => loadingMessage.remove(), 2000);

        fetchModels(); // Refresh UI
    } catch (error) {
        console.error("❌ Error deleting model:", error);
        alert("Failed to delete model. Please try again.");
    }
}
	
	function previewModel(event) {
		const file = event.target.files[0];
		if (file) {
			const fileURL = URL.createObjectURL(file);
			const modelPreview = document.getElementById("modelPreview");
			modelPreview.src = fileURL;

			const modelPreviewContainer = document.getElementById("modelPreviewContainer");
			modelPreviewContainer.style.display = "block";
		}
	}
	
	// ✅ Function to Show Preview Image Before Upload
	function previewImage(event) {
		const file = event.target.files[0];
		if (file) {
			const fileURL = URL.createObjectURL(file);
				document.getElementById("previewImageElement").src = fileURL;
				document.getElementById("previewImageContainer").style.display = "block";
			}
		}
</script>
</body>
</html>