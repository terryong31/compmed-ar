<?php
session_start();

if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_name'])) {
    header("Location: index.html");
    exit();
}

$adminName = htmlspecialchars($_SESSION['user_name']); // Safely escape the name
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompMed AR - Admin Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link rel="stylesheet" href="dashboardstyle.css">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
	<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
	<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-firestore.js"></script>
</head>

<body>
    <div class="sidebar">
        <h3>CompMed AR Admin Site</h3>
        <a href="dashboard.php">Dashboard</a>
        <a onclick="manageUserAccounts()">Account Management</a>
		<a onclick="openContentModal()">Content Management</a>
		<a href="quizmainpage.php">Assessment Management</a>
		<a onclick="manageFeedback()">Feedback Management</a>
		<a href="https://console.firebase.google.com/u/0/project/compmed-ar/notification/compose">Send Notification</a>
		<a onclick="confirmLogout()">Logout</a>
    </div>

    <div class="main-content">
        <div class="header">
            <h2>Welcome, <?php echo $adminName; ?>!</h2>
            <button id="logoutBtn" onclick="confirmLogout()">Logout</button>
        </div>

		<div class="card-container">
            <div class="card" id="account-management">
                <h3>Account Management</h3>
                <p>Manage user and lecturer accounts.</p>
                <button onclick="manageUserAccounts()">Manage Accounts</button>
            </div>
			
            <div class="card" id="content-management">
                <h3>Content Management</h3>
                <p>Manage 3D Models and Subjects.</p>
                <button class="btn btn-primary" onclick="openContentModal()">Manage Contents</button>
            </div>
		
			<div class="card" id="assessment-management">
                <h3>Assessment Management</h3>
                <p>Mark submitted assessments.</p>
                <button onclick="manageAssessment()">Manage Assessment</button>
            </div>
			
			<div class="card" id="feedback-management">
                <h3>Feedback Management</h3>
                <p>Read feedbacks from user and lecturers.</p>
                <button onclick="manageFeedback()">Manage Feedbacks</button>
            </div>
			
			<div class="card">
                <h3>Push Notification</h3>
                <p>Send a new notification to users of the app.</p>
                <button onclick="sendNotification()">Send Notification</button>
            </div>
    </div>

    <!-- ✅ MODAL FOR CONTENT SELECTION (Styled with your existing CSS) -->
    <div id="contentManagementModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeContentModal()">&times;</span>
            <h3>Select Content Type to Manage</h3>
            <p>Choose what you want to edit:</p>
            <div class="modal-options">
                <a href="skeletal_system.php" class="modal-button">🦴 3D Skeletal Systems</a>
                <a href="organ_management.php" class="modal-button">🫁 3D Organs</a>
                <a href="subjects.php" class="modal-button">📚 Subjects</a>
            </div>
        </div>
    </div>
	
	<div id="userManagementModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeContentModal1()">&times;</span>
            <h3>Select User Type to Manage</h3>
            <p>Choose what you want to edit:</p>
            <div class="modal-options">
                <a href="#" class="modal-button" onclick="verifyAdminPassword()">👤 Admin</a>
                <a href="user_management.php" class="modal-button">👥 Users</a>
            </div>
        </div>
    </div>

    <script>
	// Firebase Configuration
	const firebaseConfig = {
		apiKey: "AIzaSyC1Y7dJKv5dOBKGkMf_KYS8FNMLxWjJyE",
		authDomain: "compmed-ar.firebaseapp.com",
		projectId: "compmed-ar",
		storageBucket: "compmed-ar.appspot.com",
		messagingSenderId: "523184550566",
		appId: "1:523184550566:android:a540c878273f0f1b067a67",
		measurementId: "G-E6GVGHKWDP"
	};

	// Initialize Firebase
	if (!firebase.apps.length) {
		firebase.initializeApp(firebaseConfig);
	}

	// Initialize Firestore
	const db = firebase.firestore();

		// 🔐 Verify Admin Password Before Accessing Admin Management
		async function verifyAdminPassword() {
			const enteredPassword = prompt("Enter Developer Password:");

			if (enteredPassword === null) {
				return; // User pressed "Cancel", do nothing.
			}

			try {
				const doc = await db.collection("adminpassword").doc("password").get();
				
				if (!doc.exists) {
					alert("Error: No password found in database. Please contact support.");
					return;
				}

				const storedPassword = doc.data().password;

				if (enteredPassword === storedPassword) {
					alert("Access Granted! Redirecting...");
					window.location.href = "admin_management.php"; // ✅ Redirect if password correct
				} else {
					alert("Incorrect password! Access Denied.");
				}
			} catch (error) {
				console.error("Error fetching password from Firestore:", error);
				alert("Error verifying password. Please try again later.");
			}
		}

		function confirmLogout() {
			const isConfirmed = confirm("Are you sure you want to logout?");
			if (isConfirmed) {
				// Redirect to logout.php or call the logout function
				window.location.href = 'logout.php';
			}
		}

		function manageUserAccounts() {
			document.getElementById("userManagementModal").style.display = "flex"; // ✅ Shows only when clicked
		}

		function openContentModal() {
			document.getElementById("contentManagementModal").style.display = "flex"; // ✅ Shows only when clicked
		}

		function closeContentModal() {
			document.getElementById("contentManagementModal").style.display = "none"; // ✅ Closes properly
		}
		
		function closeContentModal1() {
			document.getElementById("userManagementModal").style.display = "none"; // ✅ Closes properly
		}

		// Close modal when clicking outside it
		window.onclick = function(event) {
			var modal = document.getElementById("contentManagementModal");
			if (event.target == modal) {
				modal.style.display = "none";
			}
		};

		function manageAssessment() {
			// Navigate to the content management page
			window.location.href = "quizmainpage.php";
		}

        function manageFeedback() {
            window.location.href = "manage_feedback.php";
        }
		
		function sendNotification() {
			window.location.href = "https://console.firebase.google.com/u/0/project/compmed-ar/notification/compose";
		}
    </script>
    <!-- ✅ Keep only Bootstrap JS (For smoother modal transitions, no CSS changes) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
