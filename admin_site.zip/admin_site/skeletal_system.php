﻿<?php
session_start();
require 'firebase_config.php'; // Ensure Firebase is configured

if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_name'])) {
    header("Location: index.html");
    exit();
}

$adminName = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skeletal System Management</title>

    <!-- ✅ Firebase SDK for Firestore & Storage -->
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-firestore.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-storage.js"></script>

    <script>
        // ✅ Firebase Configuration
        const firebaseConfig = {
            apiKey: "AIzaSyC1Y7dJKv5dOBKGkMf_KYS8FNMLxwFjJyE",
            authDomain: "compmed-ar.firebaseapp.com",
            projectId: "compmed-ar",
            storageBucket: "compmed-ar.appspot.com",
            messagingSenderId: "523184550566",
            appId: "1:523184550566:android:a540c878273f0f1b067a67",
            measurementId: "G-E6GVGHKWDP"
        };

        // ✅ Initialize Firebase
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        }

        const db = firebase.firestore();
        const storage = firebase.storage();
    </script>

<link rel="stylesheet" type="text/css" href="skeletal_system_style.css">

</head>
<body>
    <!-- ✅ Return to Dashboard Button -->
    <a href="dashboard.php" class="dashboard-btn">⬅ Return to Dashboard</a>

    <div class="container">
        <h2>Upload 3D Skeletal System Models</h2>
        <form id="uploadForm">
            <label for="gender">Select Gender:</label>
            <select id="gender" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>

            <label for="system">Select System Type:</label>
            <select id="system" required>
                <option value="Full Skeleton">Full Skeleton</option>
                <option value="Skull">Skull</option>
                <option value="Spine">Spine</option>
                <option value="Ribcage">Ribcage</option>
                <option value="Legs">Legs</option>
                <option value="Arms">Arms</option>
                <option value="Connective Tissue">Connective Tissue</option>
                <option value="Arterial System">Arterial System</option>
                <option value="Muscle System">Muscle System</option>
            </select>

            <label for="description">Model Description:</label>
            <textarea id="description" placeholder="Enter description..." required></textarea>

            <label for="modelFile">Upload 3D Model (GLB/GLTF):</label>
            <input type="file" id="modelFile" accept=".glb,.gltf" required>

            <label for="previewImage">Upload Preview Image:</label>
            <input type="file" id="previewImage" accept="image/*" required>

            <button type="submit">Upload Model</button>
			<!-- Upload Progress Bar -->
			<div id="uploadProgressContainer" style="display: none; width: 100%; background: #ddd; margin-top: 10px; border-radius: 5px;">
				<div id="uploadProgressBar" style="width: 0%; height: 5px; background: green; border-radius: 5px;"></div>
			</div>
        </form>
        <br><br>
        <h3>Uploaded Models</h3>
			<div class="model-section">
				<div class="model-card">
					<h4>Male Skeletal Models</h4>
					<div id="maleModelList">
					</div>
				</div>
				<div class="model-card">
					<h4>Female Skeletal Models</h4>
					<div id="femaleModelList" >
					</div>
				</div>
			</div>

            <div id="editProgressContainer" style="display: none; width: 100%; background: #ddd; margin-top: 10px; border-radius: 5px;">
                <div id="editProgressBar" style="width: 0%; height: 5px; background: orange; border-radius: 5px;"></div>
            </div>
    </div>

	<!-- Edit Model Modal -->
	<div id="editModal" class="modal">
		<div class="modal-content">
			<!-- Close Button -->
			<button class="close-button" onclick="closeEditModal()">❌</button>

			<h3>Edit Model Information</h3>

			<!-- Description Input -->
			<label for="editDescription"><strong>Edit Description:</strong></label>
			<textarea id="editDescription" rows="5" placeholder="Enter new description..."></textarea>

			<!-- Model File Input -->
			<label for="editModelFile"><strong>New 3D Model File (Optional):</strong></label>
			<input type="file" id="editModelFile" accept=".glb,.gltf">

			<!-- Preview Image Input -->
			<label for="editPreviewImage"><strong>New Preview Image (Optional):</strong></label>
			<input type="file" id="editPreviewImage" accept="image/*">

			<!-- Save Changes Button -->
			<button id="saveChangesBtn" onclick="saveModelChanges()">
				<i class="fas fa-save"></i> Save Changes
			</button>
		</div>
	</div>

    <script>
        firebase.auth().onAuthStateChanged(user => {
        if (!user) {
            alert("You must be signed in to update models.");
            window.location.href = "login.php"; // Redirect to login page
        }
    });

        let currentModelId = "";

		document.getElementById('uploadForm').addEventListener('submit', async function(event) {
			event.preventDefault();

			const gender = document.getElementById('gender').value;
			const system = document.getElementById('system').value;
			const description = document.getElementById('description').value;
			const modelFile = document.getElementById('modelFile').files[0];
			const previewImage = document.getElementById('previewImage').files[0];

			if (!modelFile || !previewImage) {
				alert("Please select both a model file and a preview image.");
				return;
			}

			const uploadButton = document.querySelector("#uploadForm button");
			uploadButton.disabled = true;
			uploadButton.innerHTML = "Uploading... ⏳";

			const progressContainer = document.getElementById("uploadProgressContainer");
			const progressBar = document.getElementById("uploadProgressBar");
			progressContainer.style.display = "block";
			progressBar.style.width = "0%";

			try {
				// ✅ Upload Model File with Progress
				const modelRef = storage.ref(`skeletal_system/${gender}/${system}/${modelFile.name}`);
				const modelUploadTask = modelRef.put(modelFile);

				modelUploadTask.on("state_changed", (snapshot) => {
					const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
					progressBar.style.width = `${progress}%`;
				});

				await modelUploadTask;
				const modelURL = await modelRef.getDownloadURL();

				// ✅ Upload Preview Image with Progress
				const previewRef = storage.ref(`skeletal_system/${gender}/${system}/previews/${previewImage.name}`);
				const previewUploadTask = previewRef.put(previewImage);

				previewUploadTask.on("state_changed", (snapshot) => {
					const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
					progressBar.style.width = `${progress}%`;
				});

				await previewUploadTask;
				const previewURL = await previewRef.getDownloadURL();

				// ✅ Save Data to Firestore
				await db.collection("skeletal_models").add({
					fileName: modelFile.name,
					description: description,
					gender: gender,
					system: system,
					fileURL: modelURL,
					previewImage: previewURL,
					createdAt: firebase.firestore.FieldValue.serverTimestamp()
				});

				alert("Upload successful! ✅");
				fetchModels(); // Refresh list
			} catch (error) {
				alert("Upload failed: ❌ " + error.message);
			} finally {
				uploadButton.disabled = false;
				uploadButton.innerHTML = "Upload Model";
				progressContainer.style.display = "none";
			}
		});

        async function fetchModels() {
            const maleModelList = document.getElementById('maleModelList');
            const femaleModelList = document.getElementById('femaleModelList');
            maleModelList.innerHTML = "";
            femaleModelList.innerHTML = "";

            const querySnapshot = await db.collection("skeletal_models").orderBy("createdAt", "desc").get();
            querySnapshot.forEach(doc => {
                const data = doc.data();
                const li = document.createElement("div");
                li.classList.add("model-item");

                // ✅ Container for Image & Info
                const modelInfo = document.createElement("div");
                modelInfo.classList.add("model-info");

                const img = document.createElement("img");
                img.src = data.previewImage;
                modelInfo.appendChild(img);

                const modelText = document.createElement("span");
                modelText.innerHTML = `${data.gender.toUpperCase()} - ${data.system.toUpperCase()}: 
                                    <a href="${data.fileURL}" target="_blank">${data.fileName}</a>`;
                modelInfo.appendChild(modelText);

                // ✅ Button Container
                const buttonContainer = document.createElement("div");
                buttonContainer.classList.add("button-container");

                const editButton = document.createElement("button");
                editButton.textContent = "Edit";
                editButton.onclick = () => openEditModal(doc.id, data.description, data.fileURL, data.previewImage);

                const deleteButton = document.createElement("button");
                deleteButton.textContent = "Delete";
                deleteButton.onclick = () => deleteModel(doc.id, data.fileURL, data.previewImage);

                buttonContainer.appendChild(editButton);
                buttonContainer.appendChild(deleteButton);

                li.appendChild(modelInfo);
                li.appendChild(buttonContainer);

                // ✅ Separate Male & Female Models
                if (data.gender === "male") {
                    maleModelList.appendChild(li);
                } else {
                    femaleModelList.appendChild(li);
                }
            });
        }

		// Open Modal with Edit Data
		function openEditModal(modelId, description, fileURL, previewURL) {
			currentModelId = modelId;

			// Set description
			document.getElementById("editDescription").value = description;

			// Display modal
			const modal = document.getElementById("editModal");
			modal.style.display = "flex";
		}

		// Close Modal
		function closeEditModal() {
			const modal = document.getElementById("editModal");
			modal.style.display = "none";
		}

		// Handle Save Changes
		async function saveModelChanges() {
			const newDescription = document.getElementById("editDescription").value;
			const newModelFile = document.getElementById("editModelFile").files[0];
			const newPreviewImage = document.getElementById("editPreviewImage").files[0];

			let updatedData = { description: newDescription };

			try {
				const docRef = db.collection("skeletal_models").doc(currentModelId);
				const doc = await docRef.get();

				if (!doc.exists) {
					alert("Model not found.");
					return;
				}

				const oldData = doc.data();

				// Upload new model file (if any)
				if (newModelFile) {
					try {
						await storage.refFromURL(oldData.fileURL).delete();
					} catch (error) {
						console.warn("Model file not found, uploading new one.");
					}
					const modelRef = storage.ref(`skeletal_system/${oldData.gender}/${oldData.system}/${newModelFile.name}`);
					const modelSnapshot = await modelRef.put(newModelFile);
					updatedData.fileURL = await modelSnapshot.ref.getDownloadURL();
					updatedData.fileName = newModelFile.name;
				}

				// Upload new preview image (if any)
				if (newPreviewImage) {
					try {
						await storage.refFromURL(oldData.previewImage).delete();
					} catch (error) {
						console.warn("Preview image not found, uploading new one.");
					}
					const previewRef = storage.ref(`skeletal_system/${oldData.gender}/${oldData.system}/previews/${newPreviewImage.name}`);
					const previewSnapshot = await previewRef.put(newPreviewImage);
					updatedData.previewImage = await previewSnapshot.ref.getDownloadURL();
					updatedData.previewFileName = newPreviewImage.name;
				}

				// Update Firestore with new data
				await docRef.update(updatedData);
				alert("Model updated successfully!");
				closeEditModal();
				fetchModels();
			} catch (error) {
				console.error("Error updating model:", error);
				alert("Failed to update model. Please try again.");
			}
		}

        async function deleteModel(docId, fileURL, previewURL) {
            await db.collection("skeletal_models").doc(docId).delete();
            await storage.refFromURL(fileURL).delete();
            await storage.refFromURL(previewURL).delete();
            alert("Model deleted successfully!");
            fetchModels();
        }

        fetchModels();
    </script>
</body>
</html>
