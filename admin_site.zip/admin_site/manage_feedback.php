<?php
session_start();
require 'firebase_config.php'; // Ensure Firebase is configured

if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_name'])) {
    header("Location: index.html");
    exit();
}

$adminName = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<a href="dashboard.php" class="return-btn">⬅ Return to Dashboard</a>
    <title>View & Manage Feedback</title>
	<link rel="stylesheet" type="text/css" href="feedback_styling.css">

    <!-- Firebase SDK -->
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-firestore.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-storage.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>

    <script>
        const firebaseConfig = {
            apiKey: "AIzaSyC1Y7dJKv5dOBKGkMf_KYS8FNMLxwFjJyE",
            authDomain: "compmed-ar.firebaseapp.com",
            projectId: "compmed-ar",
            storageBucket: "compmed-ar.appspot.com",
            messagingSenderId: "523184550566",
            appId: "1:523184550566:android:a540c878273f0f1b067a67",
            measurementId: "G-E6GVGHKWDP"
        };

        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        }

        const storage = firebase.storage();

        async function fetchFeedback() {
            const feedbackList = document.getElementById("feedbackList");
            feedbackList.innerHTML = "Loading feedback...";

            const feedbackRef = storage.ref("feedback");
            const usersFolders = await feedbackRef.listAll();
            feedbackList.innerHTML = "";

            for (const userFolder of usersFolders.prefixes) {
                const userFeedbacks = await userFolder.listAll();
                
                for (const feedbackFolder of userFeedbacks.prefixes) {
                    try {
                        const metadataFileRef = feedbackFolder.child("metadata.txt");
                        const metadataURL = await metadataFileRef.getDownloadURL();
                        const metadataResponse = await fetch(metadataURL);
                        const metadataText = await metadataResponse.text();
                        const metadata = {};
                        metadataText.split('\n').forEach(line => {
                            const [key, value] = line.split(': ');
                            if (key && value) metadata[key.trim()] = value.trim();
                        });

                        const row = `<tr>
                            <td>${metadata.Email || "Unknown"}</td>
                            <td>${metadata["Submitted on"] || "Unknown"}</td>
                            <td><button onclick="downloadFeedback('${feedbackFolder.fullPath}')">Download</button></td>
                            <td><button onclick="deleteFeedback('${feedbackFolder.fullPath}', this)">Delete</button></td>
                        </tr>`;
                        feedbackList.innerHTML += row;
                    } catch (error) {
                        console.warn("Skipping folder due to missing metadata.txt: ", feedbackFolder.fullPath);
                    }
                }
            }
        }

        async function downloadFeedback(feedbackPath) {
            const zip = new JSZip();
            const folderRef = storage.ref(feedbackPath);
            const files = await folderRef.listAll();

            for (const file of files.items) {
                if (file.name !== "metadata.txt") {
                    const url = await file.getDownloadURL();
                    const response = await fetch(url);
                    const blob = await response.blob();
                    zip.file(file.name, blob);
                }
            }

            const content = await zip.generateAsync({ type: "blob" });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(content);
            link.download = `feedback_${feedbackPath.replaceAll('/', '_')}.zip`;
            link.click();
        }

        async function deleteFeedback(feedbackPath, button) {
            const folderRef = storage.ref(feedbackPath);
            const files = await folderRef.listAll();

            for (const file of files.items) {
                await file.delete();
            }

            await folderRef.delete().catch(error => {
                console.warn("Error deleting folder: ", error);
            });

            alert("Feedback deleted successfully.");
            button.closest('tr').remove(); // Remove row without reloading
        }
    </script>
</head>
<body onload="fetchFeedback()">
    <h2>View & Manage Feedback</h2>
    <table border="1">
        <tr>
            <th>Email</th>
            <th>Date Submitted</th>
            <th>Attachments</th>
            <th>Actions</th>
        </tr>
        <tbody id="feedbackList"></tbody>
    </table>
</body>
</html>
