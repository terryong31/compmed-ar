<?php
session_start();

if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_name'])) {
    header("Location: index.html");
    exit();
}

$adminName = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Quizzes - CompMed AR</title>
    <script src="https://www.gstatic.com/firebasejs/9.15.0/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.15.0/firebase-firestore-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.15.0/firebase-storage-compat.js"></script>
    <script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4;
        }

        h1, h2, h3 {
            color: #333;
        }

        .navigation-section {
            margin-bottom: 20px;
        }

        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            margin-right: 10px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .nav-button:hover {
            background-color: #0056b3;
        }

        .quiz-section {
            margin-bottom: 40px;
        }

        .quiz-table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .quiz-table th, .quiz-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .quiz-table th {
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }

        .quiz-table tr:hover {
            background-color: #f1f1f1;
            cursor: pointer;
        }

        .sort-header.sort-asc::after {
            content: ' ↑';
        }

        .sort-header.sort-desc::after {
            content: ' ↓';
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
            overflow: auto; /* Ensure scrolling if content overflows */
        }

        .modal-content {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            min-width: 60%;
            max-width: 80%;
            width: auto; /* Allow it to adjust dynamically but stay at least 60% */
            max-height: 90%;
            overflow-y: auto;
            overflow-x: auto;
            position: relative;
            margin: 0 auto; /* Center the modal horizontally */
        }

        .close-button-container {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 30px;
            cursor: pointer;
            z-index: 1002;
        }

        .submission-button-container {
            position: absolute;
            top: 10px;
            right: 50px;
            font-size: 24px;
            cursor: pointer;
            z-index: 1002;
        }

        .quiz-delete-btn {
            position: absolute;
            top: 10px;
            right: 20px;
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
        }

        .quiz-delete-btn:hover {
            background-color: #c82333;
        }

        .question-wrapper {
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .question-actions {
            margin-bottom: 10px;
        }

        .edit-btn, .delete-btn, .save-btn {
            padding: 5px 10px;
            margin-right: 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        .edit-btn {
            background-color: #28a745;
            color: white;
            border: none;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
        }

        .save-btn {
            background-color: #007bff;
            color: white;
            border: none;
        }

        .edit-form {
            display: none;
            margin-top: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .edit-form input, .edit-form textarea, .edit-form select {
            width: 100%;
            margin-bottom: 10px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .model-container {
            margin-top: 10px;
        }

        model-viewer {
            width: 100%;
            height: 400px;
            background-color: #fff;
        }

        .annotation-sphere {
            position: absolute;
            width: 20px;
            height: 20px;
            transform: translate(-50%, -50%);
            pointer-events: none;
        }

        .annotation-container {
            position: absolute;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 5px 10px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            transform: translateY(20px);
            white-space: nowrap;
            pointer-events: none;
        }

        .submission-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 2000;
            overflow: auto; /* Ensure scrolling if content overflows */
        }

        .submission-modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            max-width: 80%;
            max-height: 80%;
            overflow-y: auto;
            position: relative;
            z-index: 2001;
        }

        .status-modal-close {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 30px;
            cursor: pointer;
        }

        .submission-table {
            width: 100%;
            border-collapse: collapse;
        }

        .submission-table th, .submission-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .submission-table th {
            background-color: #007bff;
            color: white;
        }
        
        .file-upload-section {
            margin-top: 20px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .selected-files-box {
            margin-top: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            min-height: 50px;
        }

        .remove-file {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        }

        #uploadGlbButton {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #uploadGlbButton:hover {
            background-color: #0056b3;
        }

        #uploadStatus {
            margin-top: 10px;
        }

        /* Media queries for smaller screens */
        @media (max-width: 768px) {
            .modal-content {
                min-width: 80%;
                padding: 20px;
            }
            .submission-modal-content {
                min-width: 80%;
                padding: 15px;
            }
            .submission-modal {
                z-index: 5000; /* Reaffirm higher z-index */
            }
        }

        @media (max-width: 480px) {
            .modal-content {
                min-width: 90%;
                padding: 15px;
            }
            .submission-modal-content {
                min-width: 90%;
                padding: 10px;
            }
            .submission-modal {
                z-index: 5000; /* Reaffirm higher z-index */
            }
        }

    </style>
</head>
<body>
    <h1>All Quizzes</h1>

    <div class="navigation-section">
        <a href="objective.php" class="nav-button">Create Objective Question</a>
        <a href="subjective.php" class="nav-button">Create Subjective Question</a>
        <a href="3d_model.php" class="nav-button">Create 3D Puzzle Question</a>
        <a href="dashboard.php" class="nav-button">Back to Dashboard</a>
    </div>

    <div class="quiz-section">
        <h2>3D Model Quizzes</h2>
        <table class="quiz-table" id="modelQuizTable">
            <thead>
                <tr>
                    <th class="sort-header" data-sort="title">Quiz Title</th>
                    <th class="sort-header" data-sort="type">Quiz Type</th>
                    <th class="sort-header" data-sort="date">Created Date</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

    <div class="quiz-section">
        <h2>Objective Quizzes</h2>
        <table class="quiz-table" id="objectiveQuizTable">
            <thead>
                <tr>
                    <th class="sort-header" data-sort="title">Quiz Title</th>
                    <th class="sort-header" data-sort="type">Quiz Type</th>
                    <th class="sort-header" data-sort="date">Created Date</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

    <div class="quiz-section">
        <h2>Subjective Quizzes</h2>
        <table class="quiz-table" id="subjectiveQuizTable">
            <thead>
                <tr>
                    <th class="sort-header" data-sort="title">Quiz Title</th>
                    <th class="sort-header" data-sort="type">Quiz Type</th>
                    <th class="sort-header" data-sort="date">Created Date</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

    <div class="file-upload-section">
        <h2>Add GLB Files (Plain 3D models for questions labelling)</h2>
        <input type="file" id="glbFileInput" accept=".glb" multiple>
        <div id="selectedFilesContainer" class="selected-files-box">
            <p>No files added.</p>
        </div>
        <div id="uploadStatus"></div>
        <button id="uploadGlbButton">Upload GLB</button>
    </div>

    <div id="questionModal" class="modal">
        <div class="close-button-container">
            <span id="closeModal" class="close">×</span>
        </div>
        <div class="submission-button-container" id="viewSubmissionBtn">
            <span class="submission-icon">📊</span>
        </div>
        <div class="modal-content">
            <h2 id="modalQuizTitle"></h2>
            <button class="quiz-delete-btn" id="deleteQuizBtn">🗑️</button>
            <h3 id="modalQuizType"></h3>
            <div id="questionsList"></div>
        </div>
    </div>

    <div id="submissionModal" class="submission-modal">
        <div class="submission-modal-content">
            <div class="status-modal-close" onclick="closeSubmissionModal()">
                <span>×</span>
            </div>
            <h3>Submissions</h3>
            <div id="submissionList"></div>
        </div>
    </div>

<script>
    const firebaseConfig = {
        apiKey: "AIzaSyBgr1QE4Wp8FCqi9HR6yVlh0", // Replace with your full Firebase API key
        authDomain: "compmed-ar.firebaseapp.com",
        databaseURL: "https://compmed-ar-default-rtdb.asia-southeast1.firebasedatabase.app/",
        projectId: "compmed-ar",
        storageBucket: "compmed-ar.appspot.com",
        messagingSenderId: "523184550566",
        appId: "1:523184550566:web:8d617dfcc526ed6c067a67",
        measurementId: "G-E6GVGHKWDP"
    };

    firebase.initializeApp(firebaseConfig);
    const db = firebase.firestore();
    const storage = firebase.storage();
    const storageRef = storage.ref();

    let allSelectedFiles = [];
    let currentQuizId = '';
    let currentQuizType = '';
    let modelsList = [];

    async function loadModelsList() {
        try {
            const modelsRef = storage.ref('plain3Dmodels');
            const modelFiles = await modelsRef.listAll();
            
            modelsList = await Promise.all(
                modelFiles.items.map(async (item) => {
                    return {
                        name: item.name,
                        path: item.fullPath,
                        url: await item.getDownloadURL()
                    };
                })
            );
        } catch (error) {
            console.error("Error loading models list:", error);
        }
    }

    function updateSelectedFilesDisplay(files) {
        const container = document.getElementById('selectedFilesContainer');
        container.innerHTML = '';

        if (!files || files.length === 0) {
            container.innerHTML = '<p>No files added.</p>';
            return;
        }

        const fileList = document.createElement('ul');
        files.forEach((file) => {
            const fileItem = document.createElement('li');
            fileItem.innerHTML = `
                ${file.name} (${(file.size / 1024).toFixed(2)} KB)
                <button class="remove-file" data-name="${file.name}">Remove</button>
            `;
            fileList.appendChild(fileItem);
        });
        container.appendChild(fileList);

        const removeButtons = container.querySelectorAll('.remove-file');
        removeButtons.forEach((button) => {
            button.addEventListener('click', (e) => {
                const fileName = e.target.getAttribute('data-name');
                allSelectedFiles = allSelectedFiles.filter(f => f.name !== fileName);
                updateSelectedFilesDisplay(allSelectedFiles);
            });
        });
    }

    document.getElementById('glbFileInput').addEventListener('change', (event) => {
        const newFiles = Array.from(event.target.files);
        newFiles.forEach((newFile) => {
            if (!allSelectedFiles.some((existingFile) => existingFile.name === newFile.name)) {
                allSelectedFiles.push(newFile);
            }
        });
        updateSelectedFilesDisplay(allSelectedFiles);
        event.target.value = '';
    });

    document.getElementById('uploadGlbButton').addEventListener('click', () => {
        const uploadStatus = document.getElementById('uploadStatus');
        if (allSelectedFiles.length === 0) {
            uploadStatus.textContent = 'Please add at least one GLB file.';
            return;
        }

        uploadStatus.textContent = '';
        const uploadPromises = [];

        allSelectedFiles.forEach((file, index) => {
            const fileRef = storageRef.child(`plain3Dmodels/${file.name}`);
            const uploadTask = fileRef.put(file);
            const fileStatus = document.createElement('div');
            fileStatus.id = `upload-status-${index}`;
            fileStatus.textContent = `Uploading ${file.name}: 0%`;
            uploadStatus.appendChild(fileStatus);

            const uploadPromise = new Promise((resolve, reject) => {
                uploadTask.on('state_changed',
                    (snapshot) => {
                        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                        fileStatus.textContent = `Uploading ${file.name}: ${progress.toFixed(2)}%`;
                    },
                    (error) => {
                        fileStatus.textContent = `Upload of ${file.name} failed: ${error.message}`;
                        fileStatus.style.color = 'red';
                        console.error(`Upload failed for ${file.name}:`, error);
                        reject(error);
                    },
                    () => {
                        uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
                            fileStatus.textContent = `${file.name} uploaded successfully! URL: ${downloadURL}`;
                            fileStatus.style.color = 'green';
                            console.log(`Uploaded ${file.name}: ${downloadURL}`);
                            resolve();
                        }).catch(reject);
                    }
                );
            });
            uploadPromises.push(uploadPromise);
        });

        Promise.all(uploadPromises)
            .then(() => {
                allSelectedFiles = [];
                updateSelectedFilesDisplay(allSelectedFiles);
                document.getElementById('glbFileInput').value = '';
                console.log('All uploads completed');
            })
            .catch((error) => console.error('Upload batch failed:', error));
    });

    async function fetchSubjectiveQuizzes() {
        try {
            console.log('Fetching subjective quizzes...');
            const quizzesSnapshot = await db.collection('questions')
                .doc('subjective_question')
                .collection('quizzes')
                .get();

            const tableBody = document.querySelector('#subjectiveQuizTable tbody');
            tableBody.innerHTML = '';

            if (quizzesSnapshot.empty) {
                tableBody.innerHTML = '<tr><td colspan="3">No subjective quizzes found</td></tr>';
                console.log('No subjective quizzes found');
                return;
            }

            quizzesSnapshot.forEach(doc => {
                const quizData = doc.data();
                const row = tableBody.insertRow();
                row.insertCell(0).textContent = quizData.quizTitle || 'Untitled';
                row.insertCell(1).textContent = quizData.quizType || 'N/A';
                row.insertCell(2).textContent = formatDate(quizData.timestamp);
                row.addEventListener('click', () => showQuestions(doc.id, 'subjective_question'));
            });
            new TableSorter('subjectiveQuizTable');
            console.log(`Loaded ${quizzesSnapshot.docs.length} subjective quizzes`);
        } catch (error) {
            console.error('Error fetching subjective quizzes:', error);
            document.querySelector('#subjectiveQuizTable tbody').innerHTML = '<tr><td colspan="3">Error loading quizzes</td></tr>';
        }
    }

    async function fetchObjectiveQuizzes() {
        try {
            console.log('Fetching objective quizzes...');
            const quizzesSnapshot = await db.collection('questions')
                .doc('objective_question')
                .collection('quizzes')
                .get();

            const tableBody = document.querySelector('#objectiveQuizTable tbody');
            tableBody.innerHTML = '';

            if (quizzesSnapshot.empty) {
                tableBody.innerHTML = '<tr><td colspan="3">No objective quizzes found</td></tr>';
                console.log('No objective quizzes found');
                return;
            }

            quizzesSnapshot.forEach(doc => {
                const quizData = doc.data();
                const row = tableBody.insertRow();
                row.insertCell(0).textContent = quizData.quizTitle || 'Untitled';
                row.insertCell(1).textContent = quizData.quizType || 'N/A';
                row.insertCell(2).textContent = formatDate(quizData.timestamp);
                row.addEventListener('click', () => showQuestions(doc.id, 'objective_question'));
            });
            new TableSorter('objectiveQuizTable');
            console.log(`Loaded ${quizzesSnapshot.docs.length} objective quizzes`);
        } catch (error) {
            console.error('Error fetching objective quizzes:', error);
            document.querySelector('#objectiveQuizTable tbody').innerHTML = '<tr><td colspan="3">Error loading quizzes</td></tr>';
        }
    }

    async function fetch3DModelQuizzes() {
        try {
            console.log('Fetching 3D model quizzes...');
            const quizzesSnapshot = await db.collection('questions')
                .doc('3Dmodel_question')
                .collection('quizzes')
                .get();

            const tableBody = document.querySelector('#modelQuizTable tbody');
            tableBody.innerHTML = '';

            if (quizzesSnapshot.empty) {
                tableBody.innerHTML = '<tr><td colspan="3">No 3D model quizzes found</td></tr>';
                console.log('No 3D model quizzes found');
                return;
            }

            quizzesSnapshot.forEach(doc => {
                const quizData = doc.data();
                const row = tableBody.insertRow();
                row.insertCell(0).textContent = quizData.quizTitle || 'Untitled';
                row.insertCell(1).textContent = quizData.quizType || 'N/A';
                row.insertCell(2).textContent = formatDate(quizData.timestamp);
                row.addEventListener('click', () => {
                    console.log(`Clicked 3D quiz ID: ${doc.id}`);
                    show3DModelQuestions(doc.id);
                });
            });
            new TableSorter('modelQuizTable');
            console.log(`Loaded ${quizzesSnapshot.docs.length} 3D model quizzes`);
        } catch (error) {
            console.error('Error fetching 3D model quizzes:', error);
            document.querySelector('#modelQuizTable tbody').innerHTML = '<tr><td colspan="3">Error loading quizzes</td></tr>';
        }
    }

    async function showQuestions(quizId, quizType) {
    try {
        console.log(`Showing questions for ${quizType} quiz ID: ${quizId}`);
        currentQuizId = quizId;
        currentQuizType = quizType;
        const modal = document.getElementById('questionModal');
        const quizTitle = document.getElementById('modalQuizTitle');
        const quizTypeElem = document.getElementById('modalQuizType');
        const questionsList = document.getElementById('questionsList');
        questionsList.innerHTML = '';

        const quizRef = db.collection('questions').doc(quizType).collection('quizzes').doc(quizId);
        const quizSnapshot = await quizRef.get();
        if (!quizSnapshot.exists) {
            console.error(`Quiz ID ${quizId} not found`);
            questionsList.innerHTML = '<p>Quiz not found.</p>';
            return;
        }
        const quizData = quizSnapshot.data();
        console.log('Quiz data:', quizData);

        quizTitle.textContent = quizData.quizTitle || 'Untitled';
        quizTypeElem.textContent = `Quiz Type: ${quizData.quizType || 'N/A'}`;

        const questionsSnapshot = await quizRef.collection(quizType === '3Dmodel_question' ? '3Dquestions' : 'questions')
            .orderBy('questionNumber')
            .get();
        console.log(`Fetched ${questionsSnapshot.size} questions`);

        if (questionsSnapshot.empty) {
            questionsList.innerHTML = '<p>No questions found for this quiz.</p>';
            console.log('No questions found');
        } else {
            questionsSnapshot.forEach(doc => {
                const questionData = doc.data();
                console.log(`Question ${doc.id}:`, questionData);
                const questionItem = document.createElement('div');
                questionItem.className = 'question-wrapper';
                questionItem.setAttribute('data-question-id', doc.id);

                let questionHeader = `Question ${questionData.questionNumber || 'N/A'}`;
                let additionalContent = '';
                if (quizType === 'subjective_question') {
                    const marks = questionData.marks !== undefined ? questionData.marks : 'N/A';
                    questionHeader += ` (${marks} marks)`;
                    const keywords = questionData.keywords && Array.isArray(questionData.keywords) 
                        ? questionData.keywords.join(', ') 
                        : 'No keywords';
                    additionalContent = `<p class="keywords-text">Keywords: ${keywords}</p>`;
                }

                questionItem.innerHTML = `
                    <div class="question-actions">
                        <button class="edit-btn" onclick="editQuestion('${doc.id}')">Edit</button>
                        <button class="delete-btn" onclick="deleteQuestion('${doc.id}')">Delete</button>
                    </div>
                    <strong>${questionHeader}:</strong> ${questionData.questionText || questionData.question || 'No text'}
                    ${additionalContent}
                    <div class="edit-form" id="edit-form-${doc.id}">
                        <input type="text" id="edit-question-text-${doc.id}" value="${questionData.questionText || questionData.question || ''}" placeholder="Question Text">
                        ${quizType !== 'subjective_question' ? `
                            <textarea id="edit-options-${doc.id}" placeholder="Options (one per line)">${questionData.options ? questionData.options.join('\n') : ''}</textarea>
                            ${quizType === 'objective_question' ? `
                                <input type="text" id="edit-correct-answer-${doc.id}" value="${questionData.correctAnswer || ''}" placeholder="Correct Answer">
                            ` : `
                                <select id="edit-model-url-${doc.id}">
                                    <option value="">Select a 3D Model</option>
                                    ${modelsList.map(model => `
                                        <option value="${model.url}" ${model.url === questionData.modelUrl ? 'selected' : ''}>${model.name}</option>
                                    `).join('')}
                                </select>
                                <textarea id="edit-annotations-${doc.id}" placeholder="Annotations (id|x|y|z|description, one per line)">${questionData.annotations ? questionData.annotations.map(a => `${a.id}|${a.x}|${a.y}|${a.z}|${a.description}`).join('\n') : ''}</textarea>
                            `}
                        ` : `
                            <input type="number" id="edit-marks-${doc.id}" min="0" value="${questionData.marks !== undefined ? questionData.marks : ''}" placeholder="Marks">
                            <input type="text" id="edit-keywords-${doc.id}" value="${questionData.keywords ? questionData.keywords.join(', ') : ''}" placeholder="Keywords (comma-separated)">
                        `}
                        <button class="save-btn" onclick="saveQuestion('${doc.id}')">Save</button>
                    </div>
                `;

                if (quizType !== 'subjective_question' && questionData.options && questionData.options.length > 0) {
                    const optionsList = document.createElement('ul');
                    questionData.options.forEach(option => {
                        const optionItem = document.createElement('li');
                        optionItem.textContent = option;
                        optionsList.appendChild(optionItem);
                    });
                    questionItem.appendChild(optionsList);
                }
                if (quizType === 'objective_question' && questionData.correctAnswer) {
                    const correctAnswerItem = document.createElement('p');
                    correctAnswerItem.innerHTML = `<strong>Correct Answer:</strong> ${questionData.correctAnswer}`;
                    questionItem.appendChild(correctAnswerItem);
                }
                questionsList.appendChild(questionItem);
            });
            console.log(`Loaded ${questionsSnapshot.docs.length} questions`);
        }
        console.log('Displaying modal');
        modal.style.display = 'flex';
    } catch (error) {
        console.error('Error showing questions:', error);
        document.getElementById('questionsList').innerHTML = `<p>Error loading questions: ${error.message}</p>`;
    }
}

async function show3DModelQuestions(quizId) {
    try {
        console.log(`Showing 3D questions for quiz ID: ${quizId}`);
        currentQuizId = quizId;
        currentQuizType = '3Dmodel_question';
        const modal = document.getElementById('questionModal');
        const quizTitle = document.getElementById('modalQuizTitle');
        const quizTypeElem = document.getElementById('modalQuizType');
        const questionsList = document.getElementById('questionsList');
        questionsList.innerHTML = '';

        const quizRef = db.collection('questions').doc('3Dmodel_question').collection('quizzes').doc(quizId);
        const quizSnapshot = await quizRef.get();
        const quizData = quizSnapshot.data();

        quizTitle.textContent = quizData.quizTitle || 'Untitled';
        quizTypeElem.textContent = `Quiz Type: ${quizData.quizType || 'N/A'}`;

        // Order only by questionNumber (single-field index should exist)
        const questionsSnapshot = await quizRef.collection('3Dquestions')
            .orderBy('questionNumber', 'asc')
            .get();

        if (questionsSnapshot.empty) {
            questionsList.innerHTML = '<p>No 3D questions found for this quiz.</p>';
            console.log('No 3D questions found');
        } else {
            let questionIndex = 0;
            for (const doc of questionsSnapshot.docs) {
                const questionData = doc.data();
                const questionDiv = document.createElement('div');
                questionDiv.className = 'question-wrapper';
                questionDiv.setAttribute('data-question-id', doc.id);

                questionDiv.innerHTML = `
                    <div class="question-actions">
                        <button class="edit-btn" onclick="editQuestion('${doc.id}')">Edit</button>
                        <button class="delete-btn" onclick="deleteQuestion('${doc.id}')">Delete</button>
                    </div>
                    <strong>Question ${questionData.questionNumber || (questionIndex + 1)}:</strong> ${questionData.question || 'No text'}
                    <div class="model-container">
                        <model-viewer
                            id="model-viewer-${quizId}-${questionIndex}"
                            src="${questionData.modelUrl}"
                            auto-rotate
                            camera-controls
                            ar
                            ar-modes="webxr scene-viewer quick-look"
                            shadow-intensity="1"
                            camera-orbit="45deg 55deg 2.5m"
                            exposure="0.2"
                            loading="lazy">
                        </model-viewer>
                    </div>
                    <div class="edit-form" id="edit-form-${doc.id}">
                        <input type="text" id="edit-question-text-${doc.id}" value="${questionData.question || ''}" placeholder="Question Text">
                        <select id="edit-model-url-${doc.id}">
                            <option value="">Select a 3D Model</option>
                            ${modelsList.map(model => `
                                <option value="${model.url}" ${model.url === questionData.modelUrl ? 'selected' : ''}>${model.name}</option>
                            `).join('')}
                        </select>
                        <textarea id="edit-annotations-${doc.id}" placeholder="Annotations (id|x|y|z|nx|ny|nz|description, one per line)">
                            ${questionData.annotations ? questionData.annotations.map(a => `${a.id}|${a.x}|${a.y}|${a.z}|${a.nx}|${a.ny}|${a.nz}|${a.description}`).join('\n') : ''}
                        </textarea>
                        <button class="save-btn" onclick="saveQuestion('${doc.id}')">Save</button>
                    </div>
                `;
                questionsList.appendChild(questionDiv);

                await new Promise(resolve => setTimeout(resolve, 100));
                const modelViewer = document.getElementById(`model-viewer-${quizId}-${questionIndex}`);

                if (questionData.annotations && questionData.annotations.length > 0) {
                    questionData.annotations.forEach((annotation, annotIndex) => {
                        const uniqueAnnotationId = `annotation-${quizId}-${questionIndex}-${annotIndex}`;
                        const annotationGroup = document.createElement('div');
                        annotationGroup.setAttribute('slot', `hotspot-${uniqueAnnotationId}`);
                        annotationGroup.style.transform = 'translateX(-50%)';

                        const sphere = document.createElement('div');
                        sphere.classList.add('annotation-sphere');
                        sphere.innerHTML = `
                            <svg width="20" height="20" viewBox="0 0 20 20">
                                <defs>
                                    <radialGradient id="sphere-gradient-${uniqueAnnotationId}" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                                        <stop offset="0%" style="stop-color:rgb(255,50,50);stop-opacity:1" />
                                        <stop offset="100%" style="stop-color:rgb(200,0,0);stop-opacity:1" />
                                    </radialGradient>
                                </defs>
                                <circle cx="10" cy="10" r="10" fill="url(#sphere-gradient-${uniqueAnnotationId})" />
                            </svg>
                        `;

                        const annotationContainer = document.createElement('div');
                        annotationContainer.className = 'annotation-container';
                        const textDisplay = document.createElement('div');
                        textDisplay.className = 'annotation-text';
                        textDisplay.textContent = annotation.description;

                        annotationGroup.setAttribute('data-position', `${annotation.x} ${annotation.y} ${annotation.z}`);
                        annotationGroup.setAttribute('data-normal', `${annotation.nx} ${annotation.ny} ${annotation.nz}`);

                        annotationContainer.appendChild(textDisplay);
                        annotationGroup.appendChild(sphere);
                        annotationGroup.appendChild(annotationContainer);
                        modelViewer.appendChild(annotationGroup);
                    });
                }
                questionIndex++;
            }
            console.log(`Loaded ${questionsSnapshot.docs.length} 3D questions`);
        }
        modal.style.display = 'flex';
    } catch (error) {
        console.error('Error showing 3D model questions:', error);
        document.getElementById('questionsList').innerHTML = `<p>Error loading 3D questions: ${error.message}</p>`;
    }
}

    async function deleteQuiz() {
        if (confirm('Are you sure you want to delete this quiz and all its questions and submissions? This action cannot be undone.')) {
            try {
                console.log(`Deleting quiz: ${currentQuizId} of type: ${currentQuizType}`);
                const quizRef = db.collection('questions').doc(currentQuizType).collection('quizzes').doc(currentQuizId);

                // Delete all questions in the subcollection
                const questionsSnapshot = await quizRef.collection(currentQuizType === '3Dmodel_question' ? '3Dquestions' : 'questions').get();
                const questionDeletes = questionsSnapshot.docs.map(doc => doc.ref.delete());
                await Promise.all(questionDeletes);
                console.log(`Deleted ${questionsSnapshot.docs.length} questions`);

                // Delete all submissions in the subcollection
                const submissionsSnapshot = await quizRef.collection('submittedBy').get();
                const submissionDeletes = submissionsSnapshot.docs.map(doc => doc.ref.delete());
                await Promise.all(submissionDeletes);
                console.log(`Deleted ${submissionsSnapshot.docs.length} submissions`);

                // Delete the quiz document itself
                await quizRef.delete();
                console.log('Quiz document deleted');

                // Close the modal and refresh the quiz list
                document.getElementById('questionModal').style.display = 'none';
                if (currentQuizType === '3Dmodel_question') {
                    fetch3DModelQuizzes();
                } else if (currentQuizType === 'objective_question') {
                    fetchObjectiveQuizzes();
                } else if (currentQuizType === 'subjective_question') {
                    fetchSubjectiveQuizzes();
                }
                alert('Quiz deleted successfully!');
            } catch (error) {
                console.error('Error deleting quiz:', error);
                alert('Failed to delete quiz: ' + error.message);
            }
        }
    }

    function editQuestion(questionId) {
        const editForm = document.getElementById(`edit-form-${questionId}`);
        editForm.style.display = editForm.style.display === 'block' ? 'none' : 'block';
    }

    async function saveQuestion(questionId) {
        try {
            const questionText = document.getElementById(`edit-question-text-${questionId}`).value.trim();
            const quizRef = db.collection('questions').doc(currentQuizType).collection('quizzes').doc(currentQuizId);
            const questionDocRef = quizRef.collection(currentQuizType === '3Dmodel_question' ? '3Dquestions' : 'questions').doc(questionId);

            let updatedData = { question: questionText, questionText: questionText };

            if (currentQuizType === 'objective_question') {
                const optionsText = document.getElementById(`edit-options-${questionId}`).value.trim();
                const options = optionsText ? optionsText.split('\n').map(opt => opt.trim()).filter(opt => opt) : [];
                const correctAnswer = document.getElementById(`edit-correct-answer-${questionId}`).value.trim();
                updatedData.options = options;
                updatedData.correctAnswer = correctAnswer;
            } else if (currentQuizType === '3Dmodel_question') {
                const modelUrl = document.getElementById(`edit-model-url-${questionId}`).value;
                const annotationsText = document.getElementById(`edit-annotations-${questionId}`).value.trim();
                const annotations = annotationsText ? annotationsText.split('\n').map(line => {
                    const [id, x, y, z, nx, ny, nz, description] = line.split('|');
                    return {
                        id,
                        x: parseFloat(x),
                        y: parseFloat(y),
                        z: parseFloat(z),
                        nx: parseFloat(nx), // Parse normal x
                        ny: parseFloat(ny), // Parse normal y
                        nz: parseFloat(nz), // Parse normal z
                        description
                    };
                }).filter(a => a.id && a.description) : [];
                updatedData.modelUrl = modelUrl;
                updatedData.annotations = annotations;
            } else if (currentQuizType === 'subjective_question') {
                const marks = parseInt(document.getElementById(`edit-marks-${questionId}`).value) || 0;
                const keywordsText = document.getElementById(`edit-keywords-${questionId}`).value.trim();
                const keywords = keywordsText ? keywordsText.split(',').map(k => k.trim().toLowerCase()) : [];
                updatedData.marks = marks;
                updatedData.keywords = keywords;
            }

            await questionDocRef.update(updatedData);
            alert('Question updated successfully!');
            if (currentQuizType === '3Dmodel_question') {
                show3DModelQuestions(currentQuizId);
            } else {
                showQuestions(currentQuizId, currentQuizType);
            }
        } catch (error) {
            console.error('Error updating question:', error);
            alert('Failed to update question: ' + error.message);
        }
    }

    async function deleteQuestion(questionId) {
        if (confirm('Are you sure you want to delete this question?')) {
            try {
                const quizRef = db.collection('questions').doc(currentQuizType).collection('quizzes').doc(currentQuizId);
                await quizRef.collection(currentQuizType === '3Dmodel_question' ? '3Dquestions' : 'questions').doc(questionId).delete();
                alert('Question deleted successfully!');
                if (currentQuizType === '3Dmodel_question') {
                    show3DModelQuestions(currentQuizId);
                } else {
                    showQuestions(currentQuizId, currentQuizType);
                }
            } catch (error) {
                console.error('Error deleting question:', error);
                alert('Failed to delete question: ' + error.message);
            }
        }
    }

    async function viewSubmissions() {
        try {
            console.log(`Fetching submissions for quiz ID: ${currentQuizId}, type: ${currentQuizType}`);
            const modal = document.getElementById('submissionModal');
            const submissionList = document.getElementById('submissionList');
            submissionList.innerHTML = '';

            const questionsSnapshot = await db.collection('questions')
                .doc(currentQuizType)
                .collection('quizzes')
                .doc(currentQuizId)
                .collection(currentQuizType === '3Dmodel_question' ? '3Dquestions' : 'questions')
                .get();

            // Calculate total possible marks for subjective questions
            let totalMarks = 0;
            questionsSnapshot.forEach(doc => {
                const questionData = doc.data();
                totalMarks += questionData.marks !== undefined ? questionData.marks : 0;
            });
            const totalPossibleScore = currentQuizType === 'subjective_question' ? totalMarks : questionsSnapshot.size;

            const submissionSnapshot = await db.collection('questions')
                .doc(currentQuizType)
                .collection('quizzes')
                .doc(currentQuizId)
                .collection('submittedBy')
                .get();

            if (submissionSnapshot.empty) {
                submissionList.innerHTML = '<p>No submissions found for this quiz.</p>';
                console.log('No submissions found');
            } else {
                const table = document.createElement('table');
                table.className = 'submission-table';
                table.innerHTML = `
                    <thead>
                        <tr>
                            <th>Email</th>
                            <th>Date & Time</th>
                            <th>Score</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                `;
                const tbody = table.querySelector('tbody');

                submissionSnapshot.forEach(doc => {
                    const submissionData = doc.data();
                    const row = tbody.insertRow();
                    row.insertCell(0).textContent = doc.id;
                    row.insertCell(1).textContent = submissionData.timestamp ? formatDate(submissionData.timestamp) : 'N/A';
                    row.insertCell(2).textContent = submissionData.score !== undefined ? `${submissionData.score.toFixed(2)}/${totalPossibleScore}` : 'N/A';
                });

                submissionList.appendChild(table);
                console.log(`Loaded ${submissionSnapshot.docs.length} submissions with total possible score: ${totalPossibleScore}`);
            }
            modal.style.display = 'flex';
        } catch (error) {
            console.error('Error fetching submissions:', error);
            document.getElementById('submissionList').innerHTML = '<p>Error loading submissions</p>';
        }
    }

    function formatDate(timestamp) {
        if (!timestamp) return 'N/A';
        const date = timestamp instanceof firebase.firestore.Timestamp ? timestamp.toDate() : new Date(timestamp);
        return date.toLocaleString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    }

    class TableSorter {
        constructor(tableId) {
            this.table = document.getElementById(tableId);
            this.tbody = this.table.querySelector('tbody');
            this.headers = this.table.querySelectorAll('th.sort-header');
            this.currentSort = { column: 'date', direction: 'desc' };
            this.initSortingHandlers();
        }

        initSortingHandlers() {
            this.headers.forEach(header => {
                header.addEventListener('click', () => {
                    const sortKey = header.getAttribute('data-sort');
                    this.sortTable(sortKey);
                });
            });
        }

        sortTable(sortKey) {
            if (this.currentSort.column === sortKey) {
                this.currentSort.direction = this.currentSort.direction === 'asc' ? 'desc' : 'asc';
            } else {
                this.currentSort.column = sortKey;
                this.currentSort.direction = 'asc';
            }

            this.headers.forEach(header => {
                header.classList.remove('sort-asc', 'sort-desc');
                if (header.getAttribute('data-sort') === sortKey) {
                    header.classList.add(this.currentSort.direction === 'asc' ? 'sort-asc' : 'sort-desc');
                }
            });

            const rows = Array.from(this.tbody.querySelectorAll('tr'));
            rows.sort((a, b) => {
                let aVal = a.cells[this.getColumnIndex(sortKey)].textContent;
                let bVal = b.cells[this.getColumnIndex(sortKey)].textContent;

                if (sortKey === 'date') {
                    aVal = new Date(aVal).getTime();
                    bVal = new Date(bVal).getTime();
                }

                if (this.currentSort.direction === 'desc') [aVal, bVal] = [bVal, aVal];
                return typeof aVal === 'number' ? aVal - bVal : aVal.localeCompare(bVal);
            });

            rows.forEach(row => this.tbody.appendChild(row));
        }

        getColumnIndex(sortKey) {
            switch (sortKey) {
                case 'title': return 0;
                case 'type': return 1;
                case 'date': return 2;
                default: return 0;
            }
        }
    }

    document.querySelector('.close-button-container').addEventListener('click', () => {
        document.getElementById('questionModal').style.display = 'none';
    });

    document.getElementById('questionModal').addEventListener('click', (event) => {
        const modalContent = document.querySelector('.modal-content');
        if (!modalContent.contains(event.target) && event.target !== document.querySelector('.close-button-container') && !document.querySelector('.close-button-container').contains(event.target)) {
            document.getElementById('questionModal').style.display = 'none';
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') document.getElementById('questionModal').style.display = 'none';
    });

    document.getElementById('viewSubmissionBtn').addEventListener('click', () => {
        viewSubmissions();
    });

    document.getElementById('deleteQuizBtn').addEventListener('click', () => {
        deleteQuiz();
    });

    function closeSubmissionModal() {
        document.getElementById('submissionModal').style.display = 'none';
    }

    document.getElementById('submissionModal').addEventListener('click', (event) => {
        const modalContent = document.querySelector('.submission-modal-content');
        if (!modalContent.contains(event.target)) {
            document.getElementById('submissionModal').style.display = 'none';
        }
    });

    document.addEventListener('DOMContentLoaded', async () => {
        console.log('DOM fully loaded, initializing...');
        await loadModelsList();
        fetchSubjectiveQuizzes();
        fetchObjectiveQuizzes();
        fetch3DModelQuizzes();
        updateSelectedFilesDisplay(allSelectedFiles);
        console.log('Initialization complete');
    });
</script>
</body>
</html>