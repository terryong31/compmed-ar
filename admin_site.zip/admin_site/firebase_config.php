<?php
require 'vendor/autoload.php'; // Load Composer dependencies
use Firebase\JWT\JWT;
$adminName = htmlspecialchars($_SESSION['user_name']); 

define('SERVICE_ACCOUNT_KEY', __DIR__ . '/firebase_service_account.json');
define('FIREBASE_FIRESTORE_URL', 'https://firestore.googleapis.com/v1/projects/compmed-ar/databases/(default)/documents/');

function getAccessToken() {
    $serviceAccount = json_decode(file_get_contents(SERVICE_ACCOUNT_KEY), true);
    $now = time();
    $payload = [
        "iss" => $serviceAccount['client_email'],
        "scope" => "https://www.googleapis.com/auth/datastore",
        "aud" => "https://oauth2.googleapis.com/token",
        "iat" => $now,
        "exp" => $now + 3600,
    ];

    $jwt = JWT::encode($payload, $serviceAccount['private_key'], 'RS256');

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => 'https://oauth2.googleapis.com/token',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_POSTFIELDS => http_build_query([
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt,
        ]),
    ]);

    $response = curl_exec($curl);
    curl_close($curl);

    $data = json_decode($response, true);
    return $data['access_token'];
}

function callFirestore($url, $method = 'GET', $data = null) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);

    if ($method === 'PATCH' || $method === 'POST') {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . FIREBASE_API_KEY // If required, use your Firebase API Key
        ]);
    }

    $response = curl_exec($ch);

    if(curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }

    curl_close($ch);

    return $response;
}
?>
